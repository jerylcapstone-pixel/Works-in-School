<?php
require_once 'config.php';

$errors = [];
$success_message = "";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - TechFix Pro</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
    <style>
        .gradient-bg {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .service-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        }
        html, body {
            height: 100%;
        }
        body {
            display: flex;
            flex-direction: column;
        }
        main {
            flex: 1 0 auto;
        }
        footer {
            flex-shrink: 0;
        }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <div class="flex-shrink-0 flex items-center">
                        <i data-feather="settings" class="text-indigo-600 h-8 w-8"></i>
                        <span class="ml-2 text-xl font-bold text-gray-900">TechFix Pro</span>
                    </div>
                </div>
                <div class="hidden md:ml-6 md:flex md:items-center md:space-x-8">
                    <a href="index.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="home" class="mr-1"></i> Home
                    </a>
                    <a href="services.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="tool" class="mr-1"></i> Services
                    </a>
                    <?php if (isset($_SESSION['user_id'])) { ?>
                    <a href="book.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="calendar" class="mr-1"></i> Book Service
                    </a>
                    <a href="bookings.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="list" class="mr-1"></i> My Bookings
                    </a>
                    <a href="profile.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="user" class="mr-1"></i> Profile
                    </a>
                    <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') { ?>
                    <a href="admin_bookings.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="shield" class="mr-1"></i> Admin Panel
                    </a>
                    <?php } ?>
                    <a href="logout.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="log-out" class="mr-1"></i> Logout
                    </a>
                    <?php } else { ?>
                    <a href="login.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="log-in" class="mr-1"></i> Login
                    </a>
                    <a href="register.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="user-plus" class="mr-1"></i> Register
                    </a>
                    <?php } ?>
                </div>
                <div class="-mr-2 flex items-center md:hidden">
                    <button type="button" id="mobile-menu-button" class="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-indigo-500" aria-controls="mobile-menu" aria-expanded="false">
                        <span class="sr-only">Open main menu</span>
                        <i data-feather="menu"></i>
                    </button>
                </div>
            </div>
        </div>
        <div class="hidden md:hidden" id="mobile-menu">
            <div class="pt-2 pb-3 space-y-1">
                <a href="index.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="home" class="mr-2"></i> Home
                </a>
                <a href="services.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="tool" class="mr-2"></i> Services
                </a>
                <a href="about.php" class="bg-indigo-50 border-indigo-500 text-indigo-700 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="info" class="mr-2"></i> About Us
                </a>
                <a href="contact.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="mail" class="mr-2"></i> Contact Us
                </a>
                <?php if (isset($_SESSION['user_id'])) { ?>
                <a href="book.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="calendar" class="mr-2"></i> Book Service
                </a>
                <a href="bookings.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="list" class="mr-2"></i> My Bookings
                </a>
                <a href="profile.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="user" class="mr-2"></i> Profile
                </a>
                <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') { ?>
                <a href="admin_bookings.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="shield" class="mr-2"></i> Admin Panel
                </a>
                <?php } ?>
                <a href="logout.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="log-out" class="mr-2"></i> Logout
                </a>
                <?php } else { ?>
                <a href="login.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="log-in" class="mr-2"></i> Login
                </a>
                <a href="register.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="user-plus" class="mr-2"></i> Register
                </a>
                <?php } ?>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main>
        <div class="py-12 bg-gray-50">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="text-center" data-aos="fade-up">
                    <h2 class="text-3xl font-extrabold text-gray-900">About TechFix Pro</h2>
                    <p class="mt-4 text-lg text-gray-500">
                        Your trusted partner for all tech repair and maintenance needs.
                    </p>
                </div>
                
                <div class="mt-10 space-y-12">
                    <!-- Our Story Section -->
                    <div class="bg-white shadow-lg rounded-lg p-6" data-aos="fade-up" data-aos-delay="100">
                        <h3 class="text-2xl font-bold text-gray-900 mb-4">Our Story</h3>
                        <p class="text-gray-600">
                            Founded in 2015, TechFix Pro started as a small repair shop with a big vision: to provide reliable, 
                            affordable, and professional tech repair services to everyone. What began as a one-person operation 
                            has grown into a team of certified technicians who have successfully repaired over 10,000 devices.
                        </p>
                        <p class="mt-4 text-gray-600">
                            Our commitment to quality service and customer satisfaction has earned us a reputation as the 
                            most trusted tech repair service in the region. We continuously invest in training and equipment 
                            to stay at the forefront of technology repair.
                        </p>
                    </div>
                    
                    <!-- Mission & Vision Section -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-8" data-aos="fade-up" data-aos-delay="200">
                        <div class="bg-white shadow-lg rounded-lg p-6">
                            <div class="text-center mb-4">
                                <i data-feather="target" class="h-12 w-12 text-indigo-600 mx-auto"></i>
                            </div>
                            <h3 class="text-xl font-bold text-gray-900 mb-4 text-center">Our Mission</h3>
                            <p class="text-gray-600">
                                To provide exceptional, reliable, and affordable tech repair services that extend the life of 
                                your devices while minimizing electronic waste. We strive to make technology accessible and 
                                sustainable for everyone.
                            </p>
                        </div>
                        
                        <div class="bg-white shadow-lg rounded-lg p-6">
                            <div class="text-center mb-4">
                                <i data-feather="eye" class="h-12 w-12 text-indigo-600 mx-auto"></i>
                            </div>
                            <h3 class="text-xl font-bold text-gray-900 mb-4 text-center">Our Vision</h3>
                            <p class="text-gray-600">
                                To become the leading tech repair service provider known for innovation, sustainability, 
                                and unparalleled customer service. We aim to set the standard for excellence in the 
                                technology repair industry.
                            </p>
                        </div>
                    </div>
                    
                    <!-- Why Choose Us Section -->
                    <div class="bg-white shadow-lg rounded-lg p-6" data-aos="fade-up" data-aos-delay="300">
                        <h3 class="text-2xl font-bold text-gray-900 mb-6">Why Choose TechFix Pro?</h3>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                            <div class="text-center">
                                <div class="bg-indigo-100 rounded-full p-3 inline-flex items-center justify-center mb-3">
                                    <i data-feather="award" class="h-8 w-8 text-indigo-600"></i>
                                </div>
                                <h4 class="font-semibold text-gray-900">Certified Technicians</h4>
                                <p class="mt-2 text-sm text-gray-600">Our team consists of certified professionals with years of experience.</p>
                            </div>
                            
                            <div class="text-center">
                                <div class="bg-indigo-100 rounded-full p-3 inline-flex items-center justify-center mb-3">
                                    <i data-feather="clock" class="h-8 w-8 text-indigo-600"></i>
                                </div>
                                <h4 class="font-semibold text-gray-900">Quick Turnaround</h4>
                                <p class="mt-2 text-sm text-gray-600">Most repairs completed within 24 hours with our efficient service.</p>
                            </div>
                            
                            <div class="text-center">
                                <div class="bg-indigo-100 rounded-full p-3 inline-flex items-center justify-center mb-3">
                                    <i data-feather="dollar-sign" class="h-8 w-8 text-indigo-600"></i>
                                </div>
                                <h4 class="font-semibold text-gray-900">Affordable Pricing</h4>
                                <p class="mt-2 text-sm text-gray-600">Transparent pricing with no hidden fees or surprises.</p>
                            </div>
                            
                            <div class="text-center">
                                <div class="bg-indigo-100 rounded-full p-3 inline-flex items-center justify-center mb-3">
                                    <i data-feather="shield" class="h-8 w-8 text-indigo-600"></i>
                                </div>
                                <h4 class="font-semibold text-gray-900">Warranty Included</h4>
                                <p class="mt-2 text-sm text-gray-600">All repairs come with a comprehensive warranty for your peace of mind.</p>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Stats Section -->
                    <div class="bg-indigo-600 text-white rounded-lg p-8" data-aos="fade-up" data-aos-delay="400">
                        <div class="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
                            <div>
                                <p class="text-4xl font-bold">10,000+</p>
                                <p class="mt-2">Devices Repaired</p>
                            </div>
                            <div>
                                <p class="text-4xl font-bold">98%</p>
                                <p class="mt-2">Satisfaction Rate</p>
                            </div>
                            <div>
                                <p class="text-4xl font-bold">15</p>
                                <p class="mt-2">Certified Technicians</p>
                            </div>
                            <div>
                                <p class="text-4xl font-bold">24h</p>
                                <p class="mt-2">Average Repair Time</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="bg-gray-800">
        <div class="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-2 gap-8 md:grid-cols-4">
                <div>
                    <h3 class="text-white text-sm font-semibold tracking-wider uppercase">Services</h3>
                    <ul class="mt-4 space-y-4">
                        <li><a href="services.php#hardware-repair" class="text-gray-300 hover:text-white">Hardware Repair</a></li>
                        <li><a href="services.php#virus-removal" class="text-gray-300 hover:text-white">Virus Removal</a></li>
                        <li><a href="services.php#data-recovery" class="text-gray-300 hover:text-white">Data Recovery</a></li>
                        <li><a href="services.php#software-installation" class="text-gray-300 hover:text-white">Software Installation</a></li>
                    </ul>
                </div>
                <div>
                    <h3 class="text-white text-sm font-semibold tracking-wider uppercase">Support</h3>
                    <ul class="mt-4 space-y-4">
                        <li><a href="contact.php" class="text-gray-300 hover:text-white">Contact Us</a></li>
                    </ul>
                </div>
                <div>
                    <h3 class="text-white text-sm font-semibold tracking-wider uppercase">Company</h3>
                    <ul class="mt-4 space-y-4">
                        <li><a href="about.php" class="text-gray-300 hover:text-white">About Us</a></li>
                    </ul>
                </div>
                <div>
                    <h3 class="text-white text-sm font-semibold tracking-wider uppercase">Connect</h3>
                    <div class="mt-4 flex space-x-6">
                        <a href="#" class="text-gray-400 hover:text-white">
                            <i data-feather="facebook"></i>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-white">
                            <i data-feather="twitter"></i>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-white">
                            <i data-feather="instagram"></i>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-white">
                            <i data-feather="linkedin"></i>
                        </a>
                    </div>
                    <div class="mt-6">
                        <p class="text-gray-300">Email us at: <a href="mailto:support@techfixpro.com" class="text-indigo-400 hover:text-indigo-300">support@techfixpro.com</a></p>
                    </div>
                </div>
            </div>
            <div class="mt-12 border-t border-gray-700 pt-8">
                <p class="text-base text-gray-400 text-center">
                    &copy; 2025 TechFix Pro. All rights reserved.
                </p>
            </div>
        </div>
    </footer>

    <script>
        AOS.init();
        feather.replace();
        document.getElementById('mobile-menu-button').addEventListener('click', function() {
            const menu = document.getElementById('mobile-menu');
            menu.classList.toggle('hidden');
        });
    </script>
</body>
</html>

<?php
try {
    if (isset($conn) && $conn instanceof mysqli) {
        $conn->close();
    }
} catch (Exception $e) {
    error_log(date('[Y-m-d H:i:s] ') . "Database Close Error in about.php: " . $e->getMessage() . " in " . $e->getFile() . " on line " . $e->getLine());
}
?>