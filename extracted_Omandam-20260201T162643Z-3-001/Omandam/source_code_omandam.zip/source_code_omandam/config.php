<?php
// Error logging configuration
ini_set('display_errors', 0); // Hide errors from users
ini_set('display_startup_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', '/var/www/html/logs/error.log');

// Database configuration
define('DB_HOST', '172.27.0.1');
define('DB_USER', 'root');
define('DB_PASS', 'omandam1');
define('DB_NAME', 'techpro');

// Security settings
define('SESSION_COOKIE_SECURE', false); // Set to true for HTTPS in production
define('SESSION_COOKIE_HTTPONLY', true);
define('SESSION_COOKIE_SAMESITE', 'Strict');

// CORS Headers
header('Access-Control-Allow-Origin: *'); // Adjust for production
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type, X-CSRF-Token');
header('Access-Control-Allow-Credentials: true');

// Initialize secure session
ini_set('session.cookie_httponly', SESSION_COOKIE_HTTPONLY);
ini_set('session.cookie_secure', SESSION_COOKIE_SECURE);
ini_set('session.cookie_samesite', SESSION_COOKIE_SAMESITE);
try {
    session_start();
    // Regenerate session ID periodically
    if (!isset($_SESSION['last_regenerate'])) {
        $_SESSION['last_regenerate'] = time();
    } elseif (time() - $_SESSION['last_regenerate'] > 1800) {
        session_regenerate_id(true);
        $_SESSION['last_regenerate'] = time();
    }
    // CSRF token
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
} catch (Exception $e) {
    error_log(date('[Y-m-d H:i:s] ') . "Session Error in config.php: " . $e->getMessage() . " in " . $e->getFile() . " on line " . $e->getLine());
    http_response_code(500);
    die("Internal server error. Please try again later.");
}

// Database connection
try {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if ($conn->connect_error) {
        throw new mysqli_sql_exception("Connection failed: " . $conn->connect_error);
    }
    $conn->set_charset("utf8mb4");
} catch (mysqli_sql_exception $e) {
    error_log(date('[Y-m-d H:i:s] ') . "Database Connection Error in config.php: " . $e->getMessage() . " in " . $e->getFile() . " on line " . $e->getLine());
    http_response_code(500);
    die("Database connection failed. Please try again later.");
}
?>