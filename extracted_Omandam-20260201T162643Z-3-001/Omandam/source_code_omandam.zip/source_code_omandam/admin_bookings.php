<?php
require_once 'config.php';
try {
    if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
        header("Location: login.php");
        exit();
    }

    $errors = [];
    $success_message = "";

    // Fetch all bookings with customer usernames
    $sql = "SELECT b.id, b.user_id, u.username, b.service_type, b.booking_date, b.booking_time, b.status 
            FROM bookings b 
            JOIN users u ON b.user_id = u.id 
            ORDER BY b.created_at DESC";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new mysqli_sql_exception("Prepare failed: " . $conn->error);
    }
    $stmt->execute();
    $bookings = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    // Handle status update
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_status']) && isset($_POST['csrf_token']) && $_POST['csrf_token'] === $_SESSION['csrf_token']) {
        $booking_id = $_POST['booking_id'] ?? 0;
        $new_status = $_POST['status'] ?? '';

        if (!in_array($new_status, ['Pending', 'Confirmed', 'Completed', 'Cancelled'])) {
            $errors[] = "Invalid status selected.";
        } else {
            $update_sql = "UPDATE bookings SET status = ? WHERE id = ? AND EXISTS (SELECT 1 FROM users WHERE id = ? AND role = 'admin')";
            $stmt_update = $conn->prepare($update_sql);
            if (!$stmt_update) {
                throw new mysqli_sql_exception("Prepare failed: " . $conn->error);
            }
            $stmt_update->bind_param("sii", $new_status, $booking_id, $_SESSION['user_id']);
            if ($stmt_update->execute()) {
                $success_message = "Booking status updated successfully!";
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                header("Location: admin_bookings.php");
                exit();
            } else {
                throw new mysqli_sql_exception("Execute failed: " . $conn->error);
            }
        }
    }

    // Handle delete booking
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_booking']) && isset($_POST['csrf_token']) && $_POST['csrf_token'] === $_SESSION['csrf_token']) {
        $booking_id = $_POST['booking_id'] ?? 0;
        $delete_sql = "DELETE FROM bookings WHERE id = ? AND EXISTS (SELECT 1 FROM users WHERE id = ? AND role = 'admin')";
        $stmt_delete = $conn->prepare($delete_sql);
        if (!$stmt_delete) {
            throw new mysqli_sql_exception("Prepare failed: " . $conn->error);
        }
        $stmt_delete->bind_param("ii", $booking_id, $_SESSION['user_id']);
        if ($stmt_delete->execute()) {
            $success_message = "Booking deleted successfully!";
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            header("Location: admin_bookings.php");
            exit();
        } else {
            throw new mysqli_sql_exception("Execute failed: " . $conn->error);
        }
    } elseif ($_SERVER["REQUEST_METHOD"] == "POST" && (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token'])) {
        $errors[] = "Invalid CSRF token.";
    }
} catch (mysqli_sql_exception $e) {
    error_log(date('[Y-m-d H:i:s] ') . "Database Error in admin_bookings.php: " . $e->getMessage() . " in " . $e->getFile() . " on line " . $e->getLine());
    $errors[] = "Operation failed due to a database error.";
} catch (Exception $e) {
    error_log(date('[Y-m-d H:i:s] ') . "Unexpected Error in admin_bookings.php: " . $e->getMessage() . " in " . $e->getFile() . " on line " . $e->getLine());
    $errors[] = "An unexpected error occurred.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - TechFix Pro</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
    <style>
        .gradient-bg {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .service-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <div class="flex-shrink-0 flex items-center">
                        <i data-feather="settings" class="text-indigo-600 h-8 w-8"></i>
                        <span class="ml-2 text-xl font-bold text-gray-900">TechFix Pro</span>
                    </div>
                </div>
                <div class="hidden md:ml-6 md:flex md:items-center md:space-x-8">
                    <a href="index.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="home" class="mr-1"></i> Home
                    </a>
                    <a href="services.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="tool" class="mr-1"></i> Services
                    </a>
                    <a href="book.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="calendar" class="mr-1"></i> Book Service
                    </a>
                    <a href="bookings.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="list" class="mr-1"></i> My Bookings
                    </a>
                    <a href="profile.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="user" class="mr-1"></i> Profile
                    </a>
                    <a href="admin_bookings.php" class="text-gray-900 bg-indigo-50 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="shield" class="mr-1"></i> Admin Panel
                    </a>
                    <a href="logout.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="log-out" class="mr-1"></i> Logout
                    </a>
                </div>
                <div class="-mr-2 flex items-center md:hidden">
                    <button type="button" class="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-indigo-500" aria-controls="mobile-menu" aria-expanded="false" id="mobile-menu-button">
                        <span class="sr-only">Open main menu</span>
                        <i data-feather="menu"></i>
                    </button>
                </div>
            </div>
        </div>

        <!-- Mobile menu -->
        <div class="hidden md:hidden" id="mobile-menu">
            <div class="pt-2 pb-3 space-y-1">
                <a href="index.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="home" class="mr-2"></i> Home
                </a>
                <a href="services.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="tool" class="mr-2"></i> Services
                </a>
                <a href="book.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="calendar" class="mr-2"></i> Book Service
                </a>
                <a href="bookings.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="list" class="mr-2"></i> My Bookings
                </a>
                <a href="profile.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="user" class="mr-2"></i> Profile
                </a>
                <a href="admin_bookings.php" class="bg-indigo-50 border-indigo-500 text-indigo-700 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="shield" class="mr-2"></i> Admin Panel
                </a>
                <a href="logout.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="log-out" class="mr-2"></i> Logout
                </a>
            </div>
        </div>
    </nav>

    <!-- Admin Bookings Section -->
    <div class="py-12 bg-gray-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="bg-white shadow-lg rounded-lg p-6" data-aos="fade-up">
                <h2 class="text-2xl font-bold text-gray-900 mb-6">Admin Panel - Manage Bookings</h2>
                <?php if ($success_message) { ?>
                    <div class="mb-4 bg-green-100 border-l-4 border-green-500 text-green-700 p-4" data-aos="fade-up" data-aos-delay="100">
                        <?php echo htmlspecialchars($success_message); ?>
                    </div>
                <?php } ?>
                <?php if (!empty($errors)) { ?>
                    <div class="mb-4 bg-red-100 border-l-4 border-red-500 text-red-700 p-4" data-aos="fade-up" data-aos-delay="100">
                        <?php foreach ($errors as $error) { echo htmlspecialchars($error) . "<br>"; } ?>
                    </div>
                <?php } ?>
                <?php if (empty($bookings)) { ?>
                    <p class="text-gray-500 text-center" data-aos="fade-up" data-aos-delay="200">No bookings found.</p>
                <?php } else { ?>
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200 bg-gray-800 rounded-lg" data-aos="fade-up" data-aos-delay="200">
                            <thead class="bg-gray-900">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-200 uppercase tracking-wider">Booking ID</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-200 uppercase tracking-wider">Customer</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-200 uppercase tracking-wider">Service Type</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-200 uppercase tracking-wider">Date</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-200 uppercase tracking-wider">Time</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-200 uppercase tracking-wider">Status</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-200 uppercase tracking-wider">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-700">
                                <?php foreach ($bookings as $index => $booking) { ?>
                                    <tr class="hover:bg-gray-700" data-aos="fade-up" data-aos-delay="<?php echo 300 + ($index * 100); ?>">
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-200"><?php echo htmlspecialchars($booking['id']); ?></td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-200"><?php echo htmlspecialchars($booking['username']); ?></td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-200"><?php echo htmlspecialchars($booking['service_type']); ?></td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-200"><?php echo htmlspecialchars($booking['booking_date']); ?></td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-200"><?php echo htmlspecialchars($booking['booking_time']); ?></td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-200">
                                            <form method="POST" class="inline-flex">
                                                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                                                <input type="hidden" name="booking_id" value="<?php echo htmlspecialchars($booking['id']); ?>">
                                                <select name="status" class="block w-full py-1 px-2 border border-gray-600 bg-gray-800 text-gray-200 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" onchange="this.form.submit()">
                                                    <option value="Pending" <?php echo $booking['status'] === 'Pending' ? 'selected' : ''; ?>>Pending</option>
                                                    <option value="Confirmed" <?php echo $booking['status'] === 'Confirmed' ? 'selected' : ''; ?>>Confirmed</option>
                                                    <option value="Completed" <?php echo $booking['status'] === 'Completed' ? 'selected' : ''; ?>>Completed</option>
                                                    <option value="Cancelled" <?php echo $booking['status'] === 'Cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                                </select>
                                                <input type="hidden" name="update_status" value="1">
                                            </form>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-200">
                                            <form method="POST" class="inline-flex" onsubmit="return confirm('Are you sure you want to delete this booking?');">
                                                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                                                <input type="hidden" name="booking_id" value="<?php echo htmlspecialchars($booking['id']); ?>">
                                                <button type="submit" name="delete_booking" class="text-red-400 hover:text-red-300">
                                                    <i data-feather="trash-2" class="h-5 w-5"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-gray-800">
        <div class="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-2 gap-8 md:grid-cols-4">
                <div>
                    <h3 class="text-white text-sm font-semibold tracking-wider uppercase">Services</h3>
                    <ul class="mt-4 space-y-4">
                        <li><a href="services.php#hardware-repair" class="text-gray-300 hover:text-white">Hardware Repair</a></li>
                        <li><a href="services.php#virus-removal" class="text-gray-300 hover:text-white">Virus Removal</a></li>
                        <li><a href="services.php#data-recovery" class="text-gray-300 hover:text-white">Data Recovery</a></li>
                        <li><a href="services.php#software-installation" class="text-gray-300 hover:text-white">Software Installation</a></li>
                    </ul>
                </div>
                <div>
                    <h3 class="text-white text-sm font-semibold tracking-wider uppercase">Support</h3>
                    <ul class="mt-4 space-y-4">
                        <li><a href="#" class="text-gray-300 hover:text-white">Help Center</a></li>
                        <li><a href="#" class="text-gray-300 hover:text-white">FAQs</a></li>
                        <li><a href="#" class="text-gray-300 hover:text-white">Contact Us</a></li>
                    </ul>
                </div>
                <div>
                    <h3 class="text-white text-sm font-semibold tracking-wider uppercase">Company</h3>
                    <ul class="mt-4 space-y-4">
                        <li><a href="#" class="text-gray-300 hover:text-white">About Us</a></li>
                        <li><a href="#" class="text-gray-300 hover:text-white">Careers</a></li>
                        <li><a href="#" class="text-gray-300 hover:text-white">Privacy Policy</a></li>
                        <li><a href="#" class="text-gray-300 hover:text-white">Terms of Service</a></li>
                    </ul>
                </div>
                <div>
                    <h3 class="text-white text-sm font-semibold tracking-wider uppercase">Connect</h3>
                    <div class="mt-4 flex space-x-6">
                        <a href="#" class="text-gray-400 hover:text-white">
                            <i data-feather="facebook"></i>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-white">
                            <i data-feather="twitter"></i>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-white">
                            <i data-feather="instagram"></i>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-white">
                            <i data-feather="linkedin"></i>
                        </a>
                    </div>
                    <div class="mt-6">
                        <p class="text-gray-300">Email us at: <a href="mailto:support@techfixpro.com" class="text-indigo-400 hover:text-indigo-300">support@techfixpro.com</a></p>
                    </div>
                </div>
            </div>
            <div class="mt-12 border-t border-gray-700 pt-8">
                <p class="text-base text-gray-400 text-center">
                    &copy; 2025 TechFix Pro. All rights reserved.
                </p>
            </div>
        </div>
    </footer>

    <script>
        AOS.init();
        feather.replace();
        document.getElementById('mobile-menu-button').addEventListener('click', function() {
            const menu = document.getElementById('mobile-menu');
            menu.classList.toggle('hidden');
        });
    </script>
</body>
</html>

<?php
try {
    $conn->close();
} catch (Exception $e) {
    error_log(date('[Y-m-d H:i:s] ') . "Database Close Error in admin_bookings.php: " . $e->getMessage() . " in " . $e->getFile() . " on line " . $e->getLine());
}
?>