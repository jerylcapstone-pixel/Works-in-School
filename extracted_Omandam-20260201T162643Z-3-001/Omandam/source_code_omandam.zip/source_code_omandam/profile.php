<?php
require_once 'config.php';
try {
    if (!isset($_SESSION['user_id'])) {
        error_log(date('[Y-m-d H:i:s] ') . "Unauthorized access attempt to profile.php: No user session");
        header("Location: login.php");
        exit();
    }

    $user_id = $_SESSION['user_id'];
    $errors = [];
    $success_message = "";

    $sql = "SELECT username, email, phone, address, profile_pic FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new mysqli_sql_exception("Prepare failed: " . $conn->error);
    }
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    if (!$user) {
        throw new Exception("User not found.");
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['csrf_token']) && $_POST['csrf_token'] === $_SESSION['csrf_token']) {
        $new_username = trim($_POST['username'] ?? '');
        $new_email = trim($_POST['email'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $address = trim($_POST['address'] ?? '');
        $new_pass = $_POST['new_password'] ?? '';
        $confirm_pass = $_POST['confirm_password'] ?? '';

        // Validate inputs
        if (empty($new_username) || empty($new_email) || empty($phone) || empty($address)) {
            $errors[] = "All fields (username, email, phone, address) are required.";
        }
        if (!filter_var($new_email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = "Invalid email format.";
        }
        if (!preg_match("/^[0-9+\-\(\) ]{7,20}$/", $phone)) {
            $errors[] = "Invalid phone number format.";
        }
        if (!empty($new_pass) && $new_pass !== $confirm_pass) {
            $errors[] = "New passwords do not match.";
        }
        if (!empty($new_pass) && strlen($new_pass) < 8) {
            $errors[] = "New password must be at least 8 characters.";
        }

        // Handle profile picture upload
        $profile_pic = $user['profile_pic'];
        if (isset($_FILES['profile_pic']) && $_FILES['profile_pic']['error'] === UPLOAD_ERR_OK) {
            $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
            $file_ext = strtolower(pathinfo($_FILES['profile_pic']['name'], PATHINFO_EXTENSION));
            if (in_array($file_ext, $allowed_types) && $_FILES['profile_pic']['size'] <= 5000000) { // 5MB limit
                $new_filename = $user_id . '.' . $file_ext;
                $upload_path = '/var/www/html/prelim/uploads/' . $new_filename;
                if (move_uploaded_file($_FILES['profile_pic']['tmp_name'], $upload_path)) {
                    $profile_pic = 'uploads/' . $new_filename; // Store relative path
                    // Delete old profile picture if it exists and is different
                    if ($user['profile_pic'] && $user['profile_pic'] !== $profile_pic && file_exists('/var/www/html/' . $user['profile_pic'])) {
                        unlink('/var/www/html/' . $user['profile_pic']);
                    }
                } else {
                    $errors[] = "Failed to upload profile picture.";
                }
            } else {
                $errors[] = "Invalid file type or size for profile picture. Allowed: JPG, PNG, GIF up to 5MB.";
            }
        }

        // Update user profile
        if (empty($errors)) {
            $check_unique = "SELECT id FROM users WHERE (username = ? OR email = ?) AND id != ?";
            $stmt_unique = $conn->prepare($check_unique);
            if (!$stmt_unique) {
                throw new mysqli_sql_exception("Prepare failed: " . $conn->error);
            }
            $stmt_unique->bind_param("ssi", $new_username, $new_email, $user_id);
            $stmt_unique->execute();
            if ($stmt_unique->get_result()->num_rows > 0) {
                $errors[] = "Username or email already in use.";
            } else {
                $update_sql = "UPDATE users SET username = ?, email = ?, phone = ?, address = ?, profile_pic = ?";
                $types = "sssss";
                $params = [$new_username, $new_email, $phone, $address, $profile_pic];

                if (!empty($new_pass)) {
                    $hashed_pass = password_hash($new_pass, PASSWORD_DEFAULT);
                    $update_sql .= ", password = ?";
                    $types .= "s";
                    $params[] = $hashed_pass;
                }

                $update_sql .= " WHERE id = ?";
                $types .= "i";
                $params[] = $user_id;

                $stmt_update = $conn->prepare($update_sql);
                if (!$stmt_update) {
                    throw new mysqli_sql_exception("Prepare failed: " . $conn->error);
                }
                $stmt_update->bind_param($types, ...$params);
                if ($stmt_update->execute()) {
                    $success_message = "Profile updated successfully!";
                    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                    $stmt->execute();
                    $user = $stmt->get_result()->fetch_assoc();
                } else {
                    throw new mysqli_sql_exception("Execute failed: " . $conn->error);
                }
            }
        }
    } elseif ($_SERVER["REQUEST_METHOD"] == "POST") {
        $errors[] = "Invalid CSRF token.";
    }
} catch (mysqli_sql_exception $e) {
    error_log(date('[Y-m-d H:i:s] ') . "Database Error in profile.php: " . $e->getMessage() . " (Code: " . $e->getCode() . ") in " . $e->getFile() . " on line " . $e->getLine());
    $errors[] = ($_SESSION['role'] === 'admin') ? "Database error: " . htmlspecialchars($e->getMessage()) : "Profile update failed due to a database error.";
} catch (Exception $e) {
    error_log(date('[Y-m-d H:i:s] ') . "Unexpected Error in profile.php: " . $e->getMessage() . " in " . $e->getFile() . " on line " . $e->getLine());
    $errors[] = "An unexpected error occurred.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile - TechFix Pro</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
    <style>
        .gradient-bg {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .service-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        }
        html, body {
            height: 100%;
        }
        body {
            display: flex;
            flex-direction: column;
        }
        main {
            flex: 1 0 auto;
        }
        footer {
            flex-shrink: 0;
        }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <div class="flex-shrink-0 flex items-center">
                        <i data-feather="settings" class="text-indigo-600 h-8 w-8"></i>
                        <span class="ml-2 text-xl font-bold text-gray-900">TechFix Pro</span>
                    </div>
                </div>
                <div class="hidden md:ml-6 md:flex md:items-center md:space-x-8">
                    <a href="index.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="home" class="mr-1"></i> Home
                    </a>
                    <a href="services.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="tool" class="mr-1"></i> Services
                    </a>
                    <a href="book.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="calendar" class="mr-1"></i> Book Service
                    </a>
                    <a href="bookings.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="list" class="mr-1"></i> My Bookings
                    </a>
                    <a href="profile.php" class="text-gray-900 bg-indigo-50 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="user" class="mr-1"></i> Profile
                    </a>
                    <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') { ?>
                    <a href="admin_bookings.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="shield" class="mr-1"></i> Admin Panel
                    </a>
                    <?php } ?>
                    <a href="logout.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="log-out" class="mr-1"></i> Logout
                    </a>
                </div>
                <div class="-mr-2 flex items-center md:hidden">
                    <button type="button" class="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-indigo-500" aria-controls="mobile-menu" aria-expanded="false" id="mobile-menu-button">
                        <span class="sr-only">Open main menu</span>
                        <i data-feather="menu"></i>
                    </button>
                </div>
            </div>
        </div>
        <div class="hidden md:hidden" id="mobile-menu">
            <div class="pt-2 pb-3 space-y-1">
                <a href="index.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="home" class="mr-2"></i> Home
                </a>
                <a href="services.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="tool" class="mr-2"></i> Services
                </a>
                <a href="book.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="calendar" class="mr-2"></i> Book Service
                </a>
                <a href="bookings.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="list" class="mr-2"></i> My Bookings
                </a>
                <a href="profile.php" class="bg-indigo-50 border-indigo-500 text-indigo-700 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="user" class="mr-2"></i> Profile
                </a>
                <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') { ?>
                <a href="admin_bookings.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="shield" class="mr-2"></i> Admin Panel
                </a>
                <?php } ?>
                <a href="logout.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="log-out" class="mr-2"></i> Logout
                </a>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main>
        <div class="py-12 bg-gray-50">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="max-w-md mx-auto">
                    <div class="bg-white shadow-lg rounded-lg p-6" data-aos="fade-up">
                        <h2 class="text-2xl font-bold text-gray-900 mb-6">Edit Profile</h2>
                        <?php if ($success_message) { ?>
                            <div class="mb-4 bg-green-100 border-l-4 border-green-500 text-green-700 p-4" data-aos="fade-up" data-aos-delay="100">
                                <?php echo htmlspecialchars($success_message); ?>
                            </div>
                        <?php } ?>
                        <?php if (!empty($errors)) { ?>
                            <div class="mb-4 bg-red-100 border-l-4 border-red-500 text-red-700 p-4" data-aos="fade-up" data-aos-delay="100">
                                <?php foreach ($errors as $error) { echo htmlspecialchars($error) . "<br>"; } ?>
                            </div>
                        <?php } ?>
                        <form method="POST" enctype="multipart/form-data" class="space-y-6">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                            <div data-aos="fade-up" data-aos-delay="200">
                                <div class="flex justify-center mb-6">
                                    <img src="<?php echo htmlspecialchars($user['profile_pic'] ?? 'https://placehold.co/128x128'); ?>" alt="Profile Picture" class="w-32 h-32 rounded-full object-cover">
                                </div>
                                <label for="profile_pic" class="block text-sm font-medium text-gray-700">Profile Picture</label>
                                <div class="mt-1 relative">
                                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                        <i data-feather="image" class="h-5 w-5 text-gray-400"></i>
                                    </div>
                                    <input type="file" name="profile_pic" id="profile_pic" accept="image/jpeg,image/png,image/gif" class="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                                </div>
                            </div>
                            <div data-aos="fade-up" data-aos-delay="300">
                                <label for="username" class="block text-sm font-medium text-gray-700">Username</label>
                                <div class="mt-1 relative">
                                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                        <i data-feather="user" class="h-5 w-5 text-gray-400"></i>
                                    </div>
                                    <input type="text" name="username" id="username" class="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" value="<?php echo htmlspecialchars($user['username'] ?? ''); ?>" required>
                                </div>
                            </div>
                            <div data-aos="fade-up" data-aos-delay="400">
                                <label for="email" class="block text-sm font-medium text-gray-700">Email</label>
                                <div class="mt-1 relative">
                                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                        <i data-feather="mail" class="h-5 w-5 text-gray-400"></i>
                                    </div>
                                    <input type="email" name="email" id="email" class="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" value="<?php echo htmlspecialchars($user['email'] ?? ''); ?>" required>
                                </div>
                            </div>
                            <div data-aos="fade-up" data-aos-delay="500">
                                <label for="phone" class="block text-sm font-medium text-gray-700">Phone</label>
                                <div class="mt-1 relative">
                                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                        <i data-feather="phone" class="h-5 w-5 text-gray-400"></i>
                                    </div>
                                    <input type="text" name="phone" id="phone" class="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>" required>
                                </div>
                            </div>
                            <div data-aos="fade-up" data-aos-delay="600">
                                <label for="address" class="block text-sm font-medium text-gray-700">Address</label>
                                <div class="mt-1">
                                    <textarea name="address" id="address" class="block w-full py-2 px-3 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" required><?php echo htmlspecialchars($user['address'] ?? ''); ?></textarea>
                                </div>
                            </div>
                            <div data-aos="fade-up" data-aos-delay="700">
                                <label for="new_password" class="block text-sm font-medium text-gray-700">New Password (leave blank to keep current)</label>
                                <div class="mt-1 relative">
                                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                        <i data-feather="lock" class="h-5 w-5 text-gray-400"></i>
                                    </div>
                                    <input type="password" name="new_password" id="new_password" class="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                                </div>
                            </div>
                            <div data-aos="fade-up" data-aos-delay="800">
                                <label for="confirm_password" class="block text-sm font-medium text-gray-700">Confirm New Password</label>
                                <div class="mt-1 relative">
                                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                        <i data-feather="lock" class="h-5 w-5 text-gray-400"></i>
                                    </div>
                                    <input type="password" name="confirm_password" id="confirm_password" class="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                                </div>
                            </div>
                            <div data-aos="fade-up" data-aos-delay="900">
                                <button type="submit" class="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                                    <i data-feather="save" class="mr-2"></i> Save Changes
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="bg-gray-800">
        <div class="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-2 gap-8 md:grid-cols-4">
                <div>
                    <h3 class="text-white text-sm font-semibold tracking-wider uppercase">Services</h3>
                    <ul class="mt-4 space-y-4">
                        <li><a href="services.php#hardware-repair" class="text-gray-300 hover:text-white">Hardware Repair</a></li>
                        <li><a href="services.php#virus-removal" class="text-gray-300 hover:text-white">Virus Removal</a></li>
                        <li><a href="services.php#data-recovery" class="text-gray-300 hover:text-white">Data Recovery</a></li>
                        <li><a href="services.php#software-installation" class="text-gray-300 hover:text-white">Software Installation</a></li>
                    </ul>
                </div>
                <div>
                    <h3 class="text-white text-sm font-semibold tracking-wider uppercase">Support</h3>
                    <ul class="mt-4 space-y-4">
                        <li><a href="#" class="text-gray-300 hover:text-white">Help Center</a></li>
                        <li><a href="#" class="text-gray-300 hover:text-white">FAQs</a></li>
                        <li><a href="#" class="text-gray-300 hover:text-white">Contact Us</a></li>
                    </ul>
                </div>
                <div>
                    <h3 class="text-white text-sm font-semibold tracking-wider uppercase">Company</h3>
                    <ul class="mt-4 space-y-4">
                        <li><a href="about.php" class="text-gray-300 hover:text-white">About Us</a></li>
                    </ul>
                </div>
                <div>
                    <h3 class="text-white text-sm font-semibold tracking-wider uppercase">Connect</h3>
                    <div class="mt-4 flex space-x-6">
                        <a href="#" class="text-gray-400 hover:text-white">
                            <i data-feather="facebook"></i>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-white">
                            <i data-feather="twitter"></i>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-white">
                            <i data-feather="instagram"></i>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-white">
                            <i data-feather="linkedin"></i>
                        </a>
                    </div>
                    <div class="mt-6">
                        <p class="text-gray-300">Email us at: <a href="mailto:support@techfixpro.com" class="text-indigo-400 hover:text-indigo-300">support@techfixpro.com</a></p>
                    </div>
                </div>
            </div>
            <div class="mt-12 border-t border-gray-700 pt-8">
                <p class="text-base text-gray-400 text-center">
                    &copy; 2025 TechFix Pro. All rights reserved.
                </p>
            </div>
        </div>
    </footer>

    <script>
        AOS.init();
        feather.replace();
        document.getElementById('mobile-menu-button').addEventListener('click', function() {
            const menu = document.getElementById('mobile-menu');
            menu.classList.toggle('hidden');
        });
    </script>
</body>
</html>

<?php
try {
    if (isset($conn) && $conn instanceof mysqli) {
        $conn->close();
    }
} catch (Exception $e) {
    error_log(date('[Y-m-d H:i:s] ') . "Database Close Error in profile.php: " . $e->getMessage() . " in " . $e->getFile() . " on line " . $e->getLine());
}
?>