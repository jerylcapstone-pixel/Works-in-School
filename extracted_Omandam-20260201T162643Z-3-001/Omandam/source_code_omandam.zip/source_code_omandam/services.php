<?php
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    error_log(date('[Y-m-d H:i:s] ') . "Unauthorized access attempt to services.php: No user session");
    header("Location: login.php");
    exit();
}

$errors = [];
$success_message = "";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Services - TechFix Pro</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
    <style>
        .gradient-bg {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .service-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        }
        html, body {
            height: 100%;
        }
        body {
            display: flex;
            flex-direction: column;
        }
        main {
            flex: 1 0 auto;
        }
        footer {
            flex-shrink: 0;
        }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <div class="flex-shrink-0 flex items-center">
                        <i data-feather="settings" class="text-indigo-600 h-8 w-8"></i>
                        <span class="ml-2 text-xl font-bold text-gray-900">TechFix Pro</span>
                    </div>
                </div>
                <div class="hidden md:ml-6 md:flex md:items-center md:space-x-8">
                    <a href="index.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="home" class="mr-1"></i> Home
                    </a>
                    <a href="services.php" class="text-gray-900 bg-indigo-50 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="tool" class="mr-1"></i> Services
                    </a>
                    <?php if (isset($_SESSION['user_id'])) { ?>
                    <a href="book.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="calendar" class="mr-1"></i> Book Service
                    </a>
                    <a href="bookings.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="list" class="mr-1"></i> My Bookings
                    </a>
                    <a href="profile.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="user" class="mr-1"></i> Profile
                    </a>
                    <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') { ?>
                    <a href="admin_bookings.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="shield" class="mr-1"></i> Admin Panel
                    </a>
                    <?php } ?>
                    <a href="logout.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="log-out" class="mr-1"></i> Logout
                    </a>
                    <?php } else { ?>
                    <a href="login.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="log-in" class="mr-1"></i> Login
                    </a>
                    <a href="register.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="user-plus" class="mr-1"></i> Register
                    </a>
                    <?php } ?>
                </div>
                <div class="-mr-2 flex items-center md:hidden">
                    <button type="button" id="mobile-menu-button" class="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-indigo-500" aria-controls="mobile-menu" aria-expanded="false">
                        <span class="sr-only">Open main menu</span>
                        <i data-feather="menu"></i>
                    </button>
                </div>
            </div>
        </div>
        <div class="hidden md:hidden" id="mobile-menu">
            <div class="pt-2 pb-3 space-y-1">
                <a href="index.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="home" class="mr-2"></i> Home
                </a>
                <a href="services.php" class="bg-indigo-50 border-indigo-500 text-indigo-700 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="tool" class="mr-2"></i> Services
                </a>
                <?php if (isset($_SESSION['user_id'])) { ?>
                <a href="book.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="calendar" class="mr-2"></i> Book Service
                </a>
                <a href="bookings.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="list" class="mr-2"></i> My Bookings
                </a>
                <a href="profile.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="user" class="mr-2"></i> Profile
                </a>
                <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') { ?>
                <a href="admin_bookings.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="shield" class="mr-2"></i> Admin Panel
                </a>
                <?php } ?>
                <a href="logout.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="log-out" class="mr-2"></i> Logout
                </a>
                <?php } else { ?>
                <a href="login.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="log-in" class="mr-2"></i> Login
                </a>
                <a href="register.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="user-plus" class="mr-2"></i> Register
                </a>
                <?php } ?>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main>
        <div class="py-12 bg-gray-50">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="text-center" data-aos="fade-up">
                    <h2 class="text-3xl font-extrabold text-gray-900">Our Services</h2>
                    <p class="mt-4 text-lg text-gray-500">
                        Explore our professional repair and maintenance services for all your tech needs.
                    </p>
                </div>
                <div class="mt-10 space-y-12">
                    <div id="hardware-repair" class="bg-white shadow-lg rounded-lg p-6" data-aos="fade-up" data-aos-delay="100">
                        <img src="https://images.unsplash.com/photo-1593642632823-8f785ba67e45?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&q=80" alt="Hardware Repair" class="w-full h-64 object-cover rounded-lg mb-4">
                        <h3 class="text-xl font-bold text-gray-900">Hardware Repair</h3>
                        <p class="mt-2 text-gray-600">
                            We fix a wide range of hardware issues, including broken screens, malfunctioning keyboards, battery replacements, and motherboard repairs.
                        </p>
                        <p class="mt-2 text-sm text-gray-500">
                            Image by <a href="https://unsplash.com" class="text-indigo-600 hover:text-indigo-500">Unsplash</a>
                        </p>
                    </div>
                    <div id="virus-removal" class="bg-white shadow-lg rounded-lg p-6" data-aos="fade-up" data-aos-delay="200">
                        <img src="https://images.unsplash.com/photo-1563207153-f403bf289096?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&q=80" alt="Virus Removal" class="w-full h-64 object-cover rounded-lg mb-4">
                        <h3 class="text-xl font-bold text-gray-900">Virus Removal</h3>
                        <p class="mt-2 text-gray-600">
                            Protect your device from malware, spyware, and viruses. We perform thorough scans, remove threats, and install robust security software to keep your system safe.
                        </p>
                        <p class="mt-2 text-sm text-gray-500">
                            Image by <a href="https://unsplash.com" class="text-indigo-600 hover:text-indigo-500">Unsplash</a>
                        </p>
                    </div>
                    <div id="data-recovery" class="bg-white shadow-lg rounded-lg p-6" data-aos="fade-up" data-aos-delay="300">
                        <img src="https://images.unsplash.com/photo-1621905252507-b35492cc74b4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&q=80" alt="Data Recovery" class="w-full h-64 object-cover rounded-lg mb-4">
                        <h3 class="text-xl font-bold text-gray-900">Data Recovery</h3>
                        <p class="mt-2 text-gray-600">
                            Lost important files due to a damaged drive or accidental deletion? Our data recovery experts use advanced techniques to retrieve your valuable data from hard drives, SSDs, and other storage devices.
                        </p>
                        <p class="mt-2 text-sm text-gray-500">
                            Image by <a href="https://unsplash.com" class="text-indigo-600 hover:text-indigo-500">Unsplash</a>
                        </p>
                    </div>
                    <div id="software-installation" class="bg-white shadow-lg rounded-lg p-6" data-aos="fade-up" data-aos-delay="400">
                        <img src="https://images.unsplash.com/photo-1542831371-29b0f74f9713?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&q=80" alt="Software Installation" class="w-full h-64 object-cover rounded-lg mb-4">
                        <h3 class="text-xl font-bold text-gray-900">Software Installation</h3>
                        <p class="mt-2 text-gray-600">
                            Need new software or updates installed? We handle the installation and configuration of operating systems, applications, and drivers to ensure seamless performance.
                        </p>
                        <p class="mt-2 text-sm text-gray-500">
                            Image by <a href="https://unsplash.com" class="text-indigo-600 hover:text-indigo-500">Unsplash</a>
                        </p>
                    </div>
                </div>
                <div class="mt-10 text-center" data-aos="fade-up" data-aos-delay="500">
                    <a href="book.php" class="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700">
                        <i data-feather="calendar" class="mr-2"></i> Book a Service
                    </a>
                </div>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="bg-gray-800">
        <div class="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-2 gap-8 md:grid-cols-4">
                <div>
                    <h3 class="text-white text-sm font-semibold tracking-wider uppercase">Services</h3>
                    <ul class="mt-4 space-y-4">
                        <li><a href="#hardware-repair" class="text-gray-300 hover:text-white">Hardware Repair</a></li>
                        <li><a href="#virus-removal" class="text-gray-300 hover:text-white">Virus Removal</a></li>
                        <li><a href="#data-recovery" class="text-gray-300 hover:text-white">Data Recovery</a></li>
                        <li><a href="#software-installation" class="text-gray-300 hover:text-white">Software Installation</a></li>
                    </ul>
                </div>
                <div>
                    <h3 class="text-white text-sm font-semibold tracking-wider uppercase">Support</h3>
                    <ul class="mt-4 space-y-4">
                        <li><a href="contact.php" class="text-gray-300 hover:text-white">Contact Us</a></li>
                    </ul>
                </div>
                <div>
                    <h3 class="text-white text-sm font-semibold tracking-wider uppercase">Company</h3>
                    <ul class="mt-4 space-y-4">
                        <li><a href="about.php" class="text-gray-300 hover:text-white">About Us</a></li>
                    </ul>
                </div>
                <div>
                    <h3 class="text-white text-sm font-semibold tracking-wider uppercase">Connect</h3>
                    <div class="mt-4 flex space-x-6">
                        <a href="#" class="text-gray-400 hover:text-white">
                            <i data-feather="facebook"></i>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-white">
                            <i data-feather="twitter"></i>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-white">
                            <i data-feather="instagram"></i>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-white">
                            <i data-feather="linkedin"></i>
                        </a>
                    </div>
                    <div class="mt-6">
                        <p class="text-gray-300">Email us at: <a href="mailto:support@techfixpro.com" class="text-indigo-400 hover:text-indigo-300">support@techfixpro.com</a></p>
                    </div>
                </div>
            </div>
            <div class="mt-12 border-t border-gray-700 pt-8">
                <p class="text-base text-gray-400 text-center">
                    &copy; 2025 TechFix Pro. All rights reserved.
                </p>
            </div>
        </div>
    </footer>

    <script>
        AOS.init();
        feather.replace();
        document.getElementById('mobile-menu-button').addEventListener('click', function() {
            const menu = document.getElementById('mobile-menu');
            menu.classList.toggle('hidden');
        });
    </script>
</body>
</html>

<?php
try {
    if (isset($conn) && $conn instanceof mysqli) {
        $conn->close();
    }
} catch (Exception $e) {
    error_log(date('[Y-m-d H:i:s] ') . "Database Close Error in services.php: " . $e->getMessage() . " in " . $e->getFile() . " on line " . $e->getLine());
}
?>