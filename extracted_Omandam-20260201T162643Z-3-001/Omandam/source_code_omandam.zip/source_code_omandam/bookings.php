<?php
session_start();
// Set timezone to ensure consistent date/time handling
date_default_timezone_set('Asia/Manila');

require_once 'config.php';
try {
    // Ensure CSRF token exists
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    // Check for authenticated user
    if (!isset($_SESSION['user_id'])) {
        error_log(date('[Y-m-d H:i:s] ') . "Unauthorized access attempt to bookings.php: No user session");
        header("Location: login.php");
        exit();
    }

    $user_id = $_SESSION['user_id'];
    $errors = [];
    $success_message = "";

    // Verify database connection
    if (!$conn || $conn->connect_error) {
        error_log(date('[Y-m-d H:i:s] ') . "Database connection failed: " . ($conn ? $conn->connect_error : "No connection object"));
        throw new mysqli_sql_exception("Database connection failed: " . ($conn ? $conn->connect_error : "No connection object"));
    }

    // Check if bookings table exists
    $table_check = $conn->query("SHOW TABLES LIKE 'bookings'");
    if ($table_check->num_rows === 0) {
        throw new mysqli_sql_exception("Table 'bookings' does not exist.");
    }

    // Verify required columns in bookings table
    $required_columns = ['id', 'user_id', 'service_type', 'booking_date', 'booking_time', 'status', 'created_at'];
    $column_check = $conn->query("SHOW COLUMNS FROM bookings");
    $existing_columns = [];
    while ($row = $column_check->fetch_assoc()) {
        $existing_columns[] = $row['Field'];
    }
    $missing_columns = array_diff($required_columns, $existing_columns);
    if (!empty($missing_columns)) {
        throw new mysqli_sql_exception("Missing columns in bookings table: " . implode(', ', $missing_columns));
    }

    // Fetch user's bookings
    $sql = "SELECT id, service_type, booking_date, booking_time, status FROM bookings WHERE user_id = ? ORDER BY created_at DESC";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new mysqli_sql_exception("Prepare failed for select query: " . $conn->error);
    }
    $stmt->bind_param("i", $user_id);
    if (!$stmt->execute()) {
        throw new mysqli_sql_exception("Execute failed for select query: " . $stmt->error);
    }
    $bookings = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    // Handle cancel booking
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['cancel_booking']) && isset($_POST['csrf_token']) && $_POST['csrf_token'] === $_SESSION['csrf_token']) {
        $booking_id = filter_var($_POST['booking_id'] ?? 0, FILTER_VALIDATE_INT);
        if ($booking_id === false || $booking_id <= 0) {
            $errors[] = "Invalid booking ID.";
        } else {
            $update_sql = "UPDATE bookings SET status = 'Cancelled' WHERE id = ? AND user_id = ? AND status = 'Pending'";
            $stmt_update = $conn->prepare($update_sql);
            if (!$stmt_update) {
                throw new mysqli_sql_exception("Prepare failed for update query: " . $conn->error);
            }
            $stmt_update->bind_param("ii", $booking_id, $user_id);
            if ($stmt_update->execute()) {
                if ($stmt_update->affected_rows > 0) {
                    $success_message = "Booking cancelled successfully!";
                    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                    header("Location: bookings.php");
                    exit();
                } else {
                    $errors[] = "Unable to cancel booking. It may have already been confirmed or cancelled.";
                }
            } else {
                throw new mysqli_sql_exception("Execute failed for update query: " . $stmt_update->error);
            }
            $stmt_update->close();
        }
    } 
    // Handle reschedule booking
    elseif ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['reschedule_booking']) && isset($_POST['csrf_token']) && $_POST['csrf_token'] === $_SESSION['csrf_token']) {
        $booking_id = filter_var($_POST['booking_id'] ?? 0, FILTER_VALIDATE_INT);
        $new_date = $_POST['reschedule_date'] ?? '';
        $new_time = $_POST['reschedule_time'] ?? '';
        
        // Validate input format
        if ($booking_id === false || $booking_id <= 0) {
            $errors[] = "Invalid booking ID.";
        } elseif (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $new_date) || !preg_match('/^\d{2}:\d{2}$/', $new_time)) {
            $errors[] = "Invalid date or time format.";
        } elseif (empty($new_date) || empty($new_time)) {
            $errors[] = "Please select both date and time for rescheduling.";
        } else {
            // Validate time constraints
            $time_parts = explode(':', $new_time);
            $hour = (int)$time_parts[0];
            $minute = (int)$time_parts[1];
            
            // Check if time is within business hours (8 AM to 6 PM)
            if ($hour < 8 || $hour >= 18) {
                $errors[] = "Booking time must be between 8:00 AM and 6:00 PM.";
            } elseif ($minute !== 0) {
                $errors[] = "Booking time must be at the top of the hour (e.g., 8:00, 9:00, etc.).";
            } else {
                // Check if the new date is in the future
                try {
                    $new_datetime = new DateTime("$new_date $new_time", new DateTimeZone('Asia/Manila'));
                    $current_datetime = new DateTime('now', new DateTimeZone('Asia/Manila'));
                    
                    if ($new_datetime <= $current_datetime) {
                        $errors[] = "New booking date and time must be in the future.";
                    } else {
                        // Check closing time constraints
                        $closing_time = new DateTime("$new_date 18:00:00", new DateTimeZone('Asia/Manila'));
                        $booking_end_time = clone $new_datetime;
                        $booking_end_time->modify('+1 hour');
                        if ($booking_end_time > $closing_time) {
                            $errors[] = "Booking cannot extend beyond 6 PM closing time. Please choose an earlier time.";
                        }
                        
                        $time_until_closing = $closing_time->getTimestamp() - $new_datetime->getTimestamp();
                        if ($time_until_closing < 1 * 3600) {
                            $errors[] = "Not enough time before closing. Please book at least 1 hour before 6 PM.";
                        }
                        
                        // Check for overlapping bookings
                        $overlap_sql = "SELECT COUNT(*) as count FROM bookings WHERE booking_date = ? AND booking_time = ? AND status NOT IN ('Cancelled', 'Completed') AND id != ?";
                        $stmt_overlap = $conn->prepare($overlap_sql);
                        if (!$stmt_overlap) {
                            throw new mysqli_sql_exception("Prepare failed for overlap check: " . $conn->error);
                        }
                        $stmt_overlap->bind_param("ssi", $new_date, $new_time, $booking_id);
                        $stmt_overlap->execute();
                        $overlap_result = $stmt_overlap->get_result()->fetch_assoc();
                        if ($overlap_result['count'] > 0) {
                            $errors[] = "The selected time slot is already booked.";
                        }
                        $stmt_overlap->close();
                        
                        // Proceed with update if no errors
                        if (empty($errors)) {
                            $update_sql = "UPDATE bookings SET booking_date = ?, booking_time = ? WHERE id = ? AND user_id = ? AND status = 'Pending'";
                            $stmt_update = $conn->prepare($update_sql);
                            if (!$stmt_update) {
                                throw new mysqli_sql_exception("Prepare failed for update query: " . $conn->error);
                            }
                            $stmt_update->bind_param("ssii", $new_date, $new_time, $booking_id, $user_id);
                            if ($stmt_update->execute()) {
                                if ($stmt_update->affected_rows > 0) {
                                    $success_message = "Booking rescheduled successfully!";
                                    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                                    header("Location: bookings.php");
                                    exit();
                                } else {
                                    $errors[] = "Unable to reschedule booking. It may have already been confirmed or cancelled.";
                                }
                            } else {
                                throw new mysqli_sql_exception("Execute failed for update query: " . $stmt_update->error);
                            }
                            $stmt_update->close();
                        }
                    }
                } catch (Exception $e) {
                    $errors[] = "Invalid date or time format.";
                }
            }
        }
    } elseif ($_SERVER["REQUEST_METHOD"] == "POST") {
        $errors[] = "Invalid CSRF token.";
    }
} catch (mysqli_sql_exception $e) {
    error_log(date('[Y-m-d H:i:s] ') . "Database Error in bookings.php: " . $e->getMessage() . " (Code: " . $e->getCode() . ") in " . $e->getFile() . " on line " . $e->getLine());
    $errors[] = ($_SESSION['role'] === 'admin') ? "Database error: " . htmlspecialchars($e->getMessage()) : "Operation failed due to a database error. Please try again later.";
} catch (Exception $e) {
    error_log(date('[Y-m-d H:i:s] ') . "Unexpected Error in bookings.php: " . $e->getMessage() . " in " . $e->getFile() . " on line " . $e->getLine());
    $errors[] = "An unexpected error occurred. Please try again later.";
}

// Generate time options for business hours (8 AM to 6 PM)
$time_options = [];
for ($hour = 8; $hour < 18; $hour++) {
    $time_options[] = str_pad($hour, 2, '0', STR_PAD_LEFT) . ':00';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Bookings - TechFix Pro</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
    <style>
        .gradient-bg {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .service-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        }
        html, body {
            height: 100%;
        }
        body {
            display: flex;
            flex-direction: column;
        }
        main {
            flex: 1 0 auto;
        }
        footer {
            flex-shrink: 0;
        }
        /* Modal styles */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }
        .modal-content {
            background-color: white;
            padding: 2rem;
            border-radius: 0.5rem;
            width: 90%;
            max-width: 500px;
        }
        /* Custom styling for time slots */
        .time-slot {
            display: inline-block;
            padding: 0.5rem 1rem;
            margin: 0.25rem;
            border-radius: 0.25rem;
            cursor: pointer;
            transition: all 0.2s;
        }
        .time-slot:hover {
            background-color: #e5e7eb;
        }
        .time-slot.selected {
            background-color: #3b82f6;
            color: white;
        }
        .time-slot.unavailable {
            background-color: #ef4444;
            color: white;
            cursor: not-allowed;
        }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <div class="flex-shrink-0 flex items-center">
                        <i data-feather="settings" class="text-indigo-600 h-8 w-8"></i>
                        <span class="ml-2 text-xl font-bold text-gray-900">TechFix Pro</span>
                    </div>
                </div>
                <div class="hidden md:ml-6 md:flex md:items-center md:space-x-8">
                    <a href="index.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="home" class="mr-1"></i> Home
                    </a>
                    <a href="services.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="tool" class="mr-1"></i> Services
                    </a>
                    <a href="book.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="calendar" class="mr-1"></i> Book Service
                    </a>
                    <a href="bookings.php" class="text-gray-900 bg-indigo-50 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="list" class="mr-1"></i> My Bookings
                    </a>
                    <a href="profile.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="user" class="mr-1"></i> Profile
                    </a>
                    <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') { ?>
                    <a href="admin_bookings.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="shield" class="mr-1"></i> Admin Panel
                    </a>
                    <?php } ?>
                    <a href="logout.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="log-out" class="mr-1"></i> Logout
                    </a>
                </div>
                <div class="-mr-2 flex items-center md:hidden">
                    <button type="button" class="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-indigo-500" aria-controls="mobile-menu" aria-expanded="false" id="mobile-menu-button">
                        <span class="sr-only">Open main menu</span>
                        <i data-feather="menu"></i>
                    </button>
                </div>
            </div>
        </div>

        <!-- Mobile menu -->
        <div class="hidden md:hidden" id="mobile-menu">
            <div class="pt-2 pb-3 space-y-1">
                <a href="index.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="home" class="mr-2"></i> Home
                </a>
                <a href="services.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="tool" class="mr-2"></i> Services
                </a>
                <a href="book.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="calendar" class="mr-2"></i> Book Service
                </a>
                <a href="bookings.php" class="bg-indigo-50 border-indigo-500 text-indigo-700 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="list" class="mr-2"></i> My Bookings
                </a>
                <a href="profile.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="user" class="mr-2"></i> Profile
                </a>
                <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') { ?>
                <a href="admin_bookings.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="shield" class="mr-2"></i> Admin Panel
                </a>
                <?php } ?>
                <a href="logout.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="log-out" class="mr-2"></i> Logout
                </a>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main>
        <div class="py-12 bg-gray-50">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="bg-white shadow-lg rounded-lg p-6" data-aos="fade-up">
                    <h2 class="text-2xl font-bold text-gray-900 mb-6">My Bookings</h2>
                    <?php if ($success_message) { ?>
                        <div class="mb-4 bg-green-100 border-l-4 border-green-500 text-green-700 p-4" data-aos="fade-up" data-aos-delay="100">
                            <?php echo htmlspecialchars($success_message); ?>
                        </div>
                    <?php } ?>
                    <?php if (!empty($errors)) { ?>
                        <div class="mb-4 bg-red-100 border-l-4 border-red-500 text-red-700 p-4" data-aos="fade-up" data-aos-delay="100">
                            <?php foreach ($errors as $error) { echo htmlspecialchars($error) . "<br>"; } ?>
                        </div>
                    <?php } ?>
                    <?php if (empty($bookings)) { ?>
                        <p class="text-gray-500 text-center" data-aos="fade-up" data-aos-delay="200">No bookings found.</p>
                        <div class="text-center mt-6">
                            <a href="book.php" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                                <i data-feather="calendar" class="mr-2"></i> Book a Service
                            </a>
                        </div>
                    <?php } else { ?>
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200 bg-white rounded-lg" data-aos="fade-up" data-aos-delay="200">
                                <thead class="bg-gray-50">
                                    <tr>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Booking ID</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Service Type</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Time</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-gray-200">
                                    <?php foreach ($bookings as $index => $booking) { ?>
                                        <tr class="hover:bg-gray-50" data-aos="fade-up" data-aos-delay="<?php echo 300 + ($index * 100); ?>">
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($booking['id']); ?></td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($booking['service_type']); ?></td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($booking['booking_date']); ?></td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($booking['booking_time']); ?></td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                                <span class="px-2 py-1 text-xs rounded-full 
                                                    <?php echo $booking['status'] === 'Pending' ? 'bg-yellow-100 text-yellow-800' : ''; ?>
                                                    <?php echo $booking['status'] === 'Confirmed' ? 'bg-blue-100 text-blue-800' : ''; ?>
                                                    <?php echo $booking['status'] === 'Completed' ? 'bg-green-100 text-green-800' : ''; ?>
                                                    <?php echo $booking['status'] === 'Cancelled' ? 'bg-red-100 text-red-800' : ''; ?>">
                                                    <?php echo htmlspecialchars($booking['status']); ?>
                                                </span>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                                <?php if ($booking['status'] === 'Pending') { ?>
                                                    <div class="flex space-x-2">
                                                        <form method="POST" class="inline-flex" onsubmit="return confirm('Are you sure you want to cancel this booking?');">
                                                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                                                            <input type="hidden" name="booking_id" value="<?php echo htmlspecialchars($booking['id']); ?>">
                                                            <button type="submit" name="cancel_booking" class="text-red-600 hover:text-red-500" title="Cancel Booking">
                                                                <i data-feather="x-circle" class="h-5 w-5"></i>
                                                            </button>
                                                        </form>
                                                        <button type="button" onclick="openRescheduleModal(<?php echo htmlspecialchars($booking['id']); ?>)" class="text-indigo-600 hover:text-indigo-500" title="Reschedule Booking">
                                                            <i data-feather="calendar" class="h-5 w-5"></i>
                                                        </button>
                                                    </div>
                                                <?php } ?>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </main>

    <!-- Reschedule Modal -->
    <div id="rescheduleModal" class="modal">
        <div class="modal-content" data-aos="fade-up">
            <div class="flex justify-between items-center mb-4">
                <h3 class="text-lg font-medium text-gray-900">Reschedule Booking</h3>
                <button type="button" onclick="closeRescheduleModal()" class="text-gray-400 hover:text-gray-500">
                    <i data-feather="x" class="h-6 w-6"></i>
                </button>
            </div>
            <form id="rescheduleForm" method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                <input type="hidden" name="booking_id" id="reschedule_booking_id">
                <input type="hidden" name="reschedule_booking" value="1">
                
                <div class="space-y-4">
                    <div>
                        <label for="reschedule_date" class="block text-sm font-medium text-gray-700">New Date</label>
                        <input type="date" name="reschedule_date" id="reschedule_date" min="<?php echo date('Y-m-d'); ?>" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500" required>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">New Time</label>
                        <div id="time-slots-container" class="grid grid-cols-4 gap-2">
                            <?php foreach ($time_options as $time): ?>
                                <div class="time-slot text-center" data-time="<?php echo $time; ?>">
                                    <?php echo $time; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <input type="hidden" name="reschedule_time" id="selected_time" required>
                        <p class="mt-2 text-sm text-gray-500">Available times are between 8:00 AM and 6:00 PM</p>
                    </div>
                </div>
                
                <div class="mt-6 flex justify-end space-x-3">
                    <button type="button" onclick="closeRescheduleModal()" class="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                        Cancel
                    </button>
                    <button type="submit" class="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                        Reschedule
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-gray-800">
        <div class="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-2 gap-8 md:grid-cols-4">
                <div>
                    <h3 class="text-white text-sm font-semibold tracking-wider uppercase">Services</h3>
                    <ul class="mt-4 space-y-4">
                        <li><a href="services.php#hardware-repair" class="text-gray-300 hover:text-white">Hardware Repair</a></li>
                        <li><a href="services.php#virus-removal" class="text-gray-300 hover:text-white">Virus Removal</a></li>
                        <li><a href="services.php#data-recovery" class="text-gray-300 hover:text-white">Data Recovery</a></li>
                        <li><a href="services.php#software-installation" class="text-gray-300 hover:text-white">Software Installation</a></li>
                    </ul>
                </div>
                <div>
                    <h3 class="text-white text-sm font-semibold tracking-wider uppercase">Support</h3>
                    <ul class="mt-4 space-y-4">
                        <li><a href="contact.php" class="text-gray-300 hover:text-white">Contact Us</a></li>
                    </ul>
                </div>
                <div>
                    <h3 class="text-white text-sm font-semibold tracking-wider uppercase">Company</h3>
                    <ul class="mt-4 space-y-4">
                        <li><a href="about.php" class="text-gray-300 hover:text-white">About Us</a></li>
                    </ul>
                </div>
                <div>
                    <h3 class="text-white text-sm font-semibold tracking-wider uppercase">Connect</h3>
                    <div class="mt-4 flex space-x-6">
                        <a href="#" class="text-gray-400 hover:text-white">
                            <i data-feather="facebook"></i>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-white">
                            <i data-feather="twitter"></i>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-white">
                            <i data-feather="instagram"></i>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-white">
                            <i data-feather="linkedin"></i>
                        </a>
                    </div>
                    <div class="mt-6">
                        <p class="text-gray-300">Email us at: <a href="mailto:support@techfixpro.com" class="text-indigo-400 hover:text-indigo-300">support@techfixpro.com</a></p>
                    </div>
                </div>
            </div>
            <div class="mt-12 border-t border-gray-700 pt-8">
                <p class="text-base text-gray-400 text-center">
                    &copy; 2025 TechFix Pro. All rights reserved.
                </p>
            </div>
        </div>
    </footer>

    <script>
        AOS.init();
        feather.replace();
        
        document.getElementById('mobile-menu-button').addEventListener('click', function() {
            const menu = document.getElementById('mobile-menu');
            menu.classList.toggle('hidden');
        });

        // Time slot selection
        document.querySelectorAll('.time-slot').forEach(slot => {
            slot.addEventListener('click', function() {
                if (!this.classList.contains('unavailable')) {
                    document.querySelectorAll('.time-slot').forEach(s => s.classList.remove('selected'));
                    this.classList.add('selected');
                    document.getElementById('selected_time').value = this.getAttribute('data-time');
                }
            });
        });

        // Reschedule modal functions
        function openRescheduleModal(bookingId) {
            document.getElementById('reschedule_booking_id').value = bookingId;
            document.getElementById('rescheduleModal').style.display = 'flex';
            
            // Set minimum date to today
            const today = new Date().toISOString().split('T')[0];
            document.getElementById('reschedule_date').min = today;
            document.getElementById('reschedule_date').value = today;
            
            // Update time slots based on selected date
            document.getElementById('reschedule_date').addEventListener('change', updateTimeSlots);
            updateTimeSlots();
        }

        function updateTimeSlots() {
            const dateInput = document.getElementById('reschedule_date');
            const selectedDate = dateInput.value;
            const today = new Date().toISOString().split('T')[0];
            const now = new Date();
            const currentHour = now.getHours();
            const currentMinute = now.getMinutes();
            
            // Reset all time slots
            document.querySelectorAll('.time-slot').forEach(slot => {
                slot.classList.remove('selected', 'unavailable');
                slot.style.cursor = 'pointer';
            });
            document.getElementById('selected_time').value = '';
            
            // If selected date is today, disable past times
            if (selectedDate === today) {
                document.querySelectorAll('.time-slot').forEach(slot => {
                    const time = slot.getAttribute('data-time');
                    const [hour, minute] = time.split(':').map(Number);
                    
                    // Disable times that have already passed today
                    if (hour < currentHour || (hour === currentHour && minute < currentMinute)) {
                        slot.classList.add('unavailable');
                        slot.style.cursor = 'not-allowed';
                    }
                    
                    // Disable times that are too close to closing (6pm)
                    if (hour >= 17) { // 5pm or later
                        slot.classList.add('unavailable');
                        slot.style.cursor = 'not-allowed';
                    }
                });
            }
        }

        function closeRescheduleModal() {
            document.getElementById('rescheduleModal').style.display = 'none';
            document.getElementById('rescheduleForm').reset();
            document.querySelectorAll('.time-slot').forEach(slot => {
                slot.classList.remove('selected', 'unavailable');
                slot.style.cursor = 'pointer';
            });
        }

        // Close modal when clicking outside
        window.addEventListener('click', function(event) {
            const modal = document.getElementById('rescheduleModal');
            if (event.target === modal) {
                closeRescheduleModal();
            }
        });

        // Form validation for rescheduling
        document.getElementById('rescheduleForm').addEventListener('submit', function(e) {
            const date = document.getElementById('reschedule_date').value;
            const time = document.getElementById('selected_time').value;
            
            if (!date || !time) {
                e.preventDefault();
                alert('Please select both date and time for rescheduling.');
                return false;
            }
            
            // Validate that the selected datetime is in the future
            const selectedDatetime = new Date(date + 'T' + time + ':00');
            const now = new Date();
            
            if (selectedDatetime <= now) {
                e.preventDefault();
                alert('Please select a future date and time for rescheduling.');
                return false;
            }
            
            // Check if time is within business hours (8 AM to 6 PM)
            const hour = parseInt(time.split(':')[0]);
            if (hour < 8 || hour >= 18) {
                e.preventDefault();
                alert('Booking time must be between 8:00 AM and 6:00 PM.');
                return false;
            }
            
            // Check if booking is too close to closing time
            const closingTime = new Date(date + 'T18:00:00');
            const bookingEndTime = new Date(selectedDatetime);
            bookingEndTime.setHours(bookingEndTime.getHours() + 1);
            
            // Check if booking would end after closing time
            if (bookingEndTime > closingTime) {
                e.preventDefault();
                alert('Booking cannot extend beyond 6 PM closing time. Please choose an earlier time.');
                return false;
            }
            
            return true;
        });
    </script>
</body>
</html>

<?php
try {
    if (isset($conn) && $conn instanceof mysqli) {
        $conn->close();
    }
} catch (Exception $e) {
    error_log(date('[Y-m-d H:i:s] ') . "Database Close Error in bookings.php: " . $e->getMessage() . " in " . $e->getFile() . " on line " . $e->getLine());
}
?>