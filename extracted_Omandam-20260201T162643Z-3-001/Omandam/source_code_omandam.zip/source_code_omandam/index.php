<?php
require_once 'config.php';
try {
    // Initialize variables for errors and messages
    $errors = [];
    $success_message = "";
} catch (Exception $e) {
    error_log(date('[Y-m-d H:i:s] ') . "Unexpected Error in index.php: " . $e->getMessage() . " in " . $e->getFile() . " on line " . $e->getLine());
    $errors[] = "An unexpected error occurred.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TechFix Pro - Home</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
    <style>
        .gradient-bg {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .service-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        }
        html, body {
            height: 100%;
        }
        body {
            display: flex;
            flex-direction: column;
        }
        main {
            flex: 1 0 auto;
        }
        footer {
            flex-shrink: 0;
        }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <div class="flex-shrink-0 flex items-center">
                        <i data-feather="settings" class="text-indigo-600 h-8 w-8"></i>
                        <span class="ml-2 text-xl font-bold text-gray-900">TechFix Pro</span>
                    </div>
                </div>
                <div class="hidden md:ml-6 md:flex md:items-center md:space-x-8">
                    <a href="index.php" class="text-gray-900 bg-indigo-50 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="home" class="mr-1"></i> Home
                    </a>
                    <a href="services.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="tool" class="mr-1"></i> Services
                    </a>
                    <?php if (isset($_SESSION['user_id'])) { ?>
                    <a href="book.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="calendar" class="mr-1"></i> Book Service
                    </a>
                    <a href="bookings.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="list" class="mr-1"></i> My Bookings
                    </a>
                    <a href="profile.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="user" class="mr-1"></i> Profile
                    </a>
                    <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') { ?>
                    <a href="admin_bookings.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="shield" class="mr-1"></i> Admin Panel
                    </a>
                    <?php } ?>
                    <a href="logout.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="log-out" class="mr-1"></i> Logout
                    </a>
                    <?php } else { ?>
                    <a href="login.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="log-in" class="mr-1"></i> Login
                    </a>
                    <a href="register.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="user-plus" class="mr-1"></i> Register
                    </a>
                    <?php } ?>
                </div>
                <div class="-mr-2 flex items-center md:hidden">
                    <button type="button" class="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-indigo-500" aria-controls="mobile-menu" aria-expanded="false" id="mobile-menu-button">
                        <span class="sr-only">Open main menu</span>
                        <i data-feather="menu"></i>
                    </button>
                </div>
            </div>
        </div>
        <div class="hidden md:hidden" id="mobile-menu">
            <div class="pt-2 pb-3 space-y-1">
                <a href="index.php" class="bg-indigo-50 border-indigo-500 text-indigo-700 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="home" class="mr-2"></i> Home
                </a>
                <a href="services.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="tool" class="mr-2"></i> Services
                </a>
                <?php if (isset($_SESSION['user_id'])) { ?>
                <a href="book.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="calendar" class="mr-2"></i> Book Service
                </a>
                <a href="bookings.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="list" class="mr-2"></i> My Bookings
                </a>
                <a href="profile.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="user" class="mr-2"></i> Profile
                </a>
                <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') { ?>
                <a href="admin_bookings.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="shield" class="mr-2"></i> Admin Panel
                </a>
                <?php } ?>
                <a href="logout.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="log-out" class="mr-2"></i> Logout
                </a>
                <?php } else { ?>
                <a href="login.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="log-in" class="mr-2"></i> Login
                </a>
                <a href="register.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="user-plus" class="mr-2"></i> Register
                </a>
                <?php } ?>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main>
        <div class="gradient-bg py-12">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="text-center" data-aos="fade-up">
                    <h1 class="text-4xl font-extrabold text-white sm:text-5xl md:text-6xl">TechFix Pro</h1>
                    <p class="mt-3 max-w-md mx-auto text-base text-gray-200 sm:text-lg md:mt-5 md:text-xl">Your one-stop solution for all tech repair needs.</p>
                    <div class="mt-5 max-w-md mx-auto sm:flex sm:justify-center md:mt-8">
                        <?php if (!isset($_SESSION['user_id'])) { ?>
                        <a href="register.php" class="w-full sm:w-auto flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 md:py-4 md:text-lg md:px-10">
                            Get Started
                        </a>
                        <?php } else { ?>
                        <a href="book.php" class="w-full sm:w-auto flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 md:py-4 md:text-lg md:px-10">
                            Book Now
                        </a>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Services Section -->
        <div class="py-12 bg-gray-50">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="text-center" data-aos="fade-up">
                    <h2 class="text-3xl font-extrabold text-gray-900">Our Services</h2>
                    <p class="mt-4 text-lg text-gray-500">Explore our range of professional repair services.</p>
                </div>
                <div class="mt-10 grid gap-10 sm:grid-cols-2 lg:grid-cols-4">
                    <div class="service-card bg-white shadow-lg rounded-lg p-6 transition transform" data-aos="fade-up" data-aos-delay="100">
                        <i data-feather="monitor" class="h-12 w-12 text-indigo-600 mb-4"></i>
                        <h3 class="text-lg font-medium text-gray-900">Hardware Repair</h3>
                        <p class="mt-2 text-sm text-gray-500">Fixing broken screens, keyboards, and more.</p>
                    </div>
                    <div class="service-card bg-white shadow-lg rounded-lg p-6 transition transform" data-aos="fade-up" data-aos-delay="200">
                        <i data-feather="alert-triangle" class="h-12 w-12 text-indigo-600 mb-4"></i>
                        <h3 class="text-lg font-medium text-gray-900">Virus Removal</h3>
                        <p class="mt-2 text-sm text-gray-500">Eliminate malware and secure your device.</p>
                    </div>
                    <div class="service-card bg-white shadow-lg rounded-lg p-6 transition transform" data-aos="fade-up" data-aos-delay="300">
                        <i data-feather="hard-drive" class="h-12 w-12 text-indigo-600 mb-4"></i>
                        <h3 class="text-lg font-medium text-gray-900">Data Recovery</h3>
                        <p class="mt-2 text-sm text-gray-500">Retrieve lost files from damaged drives.</p>
                    </div>
                    <div class="service-card bg-white shadow-lg rounded-lg p-6 transition transform" data-aos="fade-up" data-aos-delay="400">
                        <i data-feather="download" class="h-12 w-12 text-indigo-600 mb-4"></i>
                        <h3 class="text-lg font-medium text-gray-900">Software Installation</h3>
                        <p class="mt-2 text-sm text-gray-500">Install and configure software seamlessly.</p>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="bg-gray-800">
        <div class="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-2 gap-8 md:grid-cols-4">
                <div>
                    <h3 class="text-white text-sm font-semibold tracking-wider uppercase">Services</h3>
                    <ul class="mt-4 space-y-4">
                        <li><a href="services.php#hardware-repair" class="text-gray-300 hover:text-white">Hardware Repair</a></li>
                        <li><a href="services.php#virus-removal" class="text-gray-300 hover:text-white">Virus Removal</a></li>
                        <li><a href="services.php#data-recovery" class="text-gray-300 hover:text-white">Data Recovery</a></li>
                        <li><a href="services.php#software-installation" class="text-gray-300 hover:text-white">Software Installation</a></li>
                    </ul>
                </div>
                <div>
                    <h3 class="text-white text-sm font-semibold tracking-wider uppercase">Support</h3>
                    <ul class="mt-4 space-y-4">
                        <li><a href="about.php" class="text-gray-300 hover:text-white">Contact Us</a></li>
                    </ul>   
                </div>
                <div>
                    <h3 class="text-white text-sm font-semibold tracking-wider uppercase">Company</h3>
                    <ul class="mt-4 space-y-4">
                        <li><a href="about.php" class="text-gray-300 hover:text-white">About Us</a></li>
                    </ul>
                </div>
                <div>
                    <h3 class="text-white text-sm font-semibold tracking-wider uppercase">Connect</h3>
                    <div class="mt-4 flex space-x-6">
                        <a href="#" class="text-gray-400 hover:text-white">
                            <i data-feather="facebook"></i>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-white">
                            <i data-feather="twitter"></i>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-white">
                            <i data-feather="instagram"></i>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-white">
                            <i data-feather="linkedin"></i>
                        </a>
                    </div>
                    <div class="mt-6">
                        <p class="text-gray-300">Email us at: <a href="mailto:support@techfixpro.com" class="text-indigo-400 hover:text-indigo-300">support@techfixpro.com</a></p>
                    </div>
                </div>
            </div>
            <div class="mt-12 border-t border-gray-700 pt-8">
                <p class="text-base text-gray-400 text-center">
                    &copy; 2025 TechFix Pro. All rights reserved.
                </p>
            </div>
        </div>
    </footer>

    <script>
        AOS.init();
        feather.replace();
        document.getElementById('mobile-menu-button').addEventListener('click', function() {
            const menu = document.getElementById('mobile-menu');
            menu.classList.toggle('hidden');
        });
    </script>
</body>
</html>

<?php
try {
    if (isset($conn) && $conn instanceof mysqli) {
        $conn->close();
    }
} catch (Exception $e) {
    error_log(date('[Y-m-d H:i:s] ') . "Database Close Error in index.php: " . $e->getMessage() . " in " . $e->getFile() . " on line " . $e->getLine());
}
?>