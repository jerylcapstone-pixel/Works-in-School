<?php
require_once 'config.php';
try {
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit();
} catch (Exception $e) {
    error_log(date('[Y-m-d H:i:s] ') . "Session Error in logout.php: " . $e->getMessage() . " in " . $e->getFile() . " on line " . $e->getLine());
    http_response_code(500);
    die("Internal server error. Please try again later.");
}
?>