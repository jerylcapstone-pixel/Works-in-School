<?php
require_once 'config.php';
try {
    $errors = [];
    $success_message = "";
    $suggested_username = "";

    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['csrf_token']) && $_POST['csrf_token'] === $_SESSION['csrf_token']) {
        $username = trim($_POST['username'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';

        // Input validation
        if (empty($username) || empty($email) || empty($password) || empty($confirm_password)) {
            $errors[] = "All fields are required.";
        }
        if (!preg_match("/^[a-zA-Z0-9]{3,30}$/", $username)) {
            $errors[] = "Username must be 3-30 characters and alphanumeric.";
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = "Invalid email format.";
        }
        if ($password !== $confirm_password) {
            $errors[] = "Passwords do not match.";
        }
        if (strlen($password) < 8) {
            $errors[] = "Password must be at least 8 characters.";
        }

        // Check for duplicate username or email
        if (empty($errors)) {
            $check_sql = "SELECT username FROM users WHERE username = ? OR email = ?";
            $stmt_check = $conn->prepare($check_sql);
            if (!$stmt_check) {
                throw new mysqli_sql_exception("Prepare failed: " . $conn->error);
            }
            $stmt_check->bind_param("ss", $username, $email);
            $stmt_check->execute();
            $result = $stmt_check->get_result();
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                if ($row['username'] === $username) {
                    // Generate suggested username
                    $base_username = preg_replace("/\d+$/", "", $username); // Remove trailing numbers
                    $attempt = 1;
                    do {
                        $suggested_username = $base_username . $attempt;
                        $check_unique = $conn->prepare("SELECT 1 FROM users WHERE username = ?");
                        if (!$check_unique) {
                            throw new mysqli_sql_exception("Prepare failed: " . $conn->error);
                        }
                        $check_unique->bind_param("s", $suggested_username);
                        $check_unique->execute();
                        $unique_result = $check_unique->get_result();
                        $attempt++;
                    } while ($unique_result->num_rows > 0 && $attempt <= 100);
                    if ($attempt > 100) {
                        $errors[] = "Unable to suggest a unique username. Please choose a different username.";
                    } else {
                        $errors[] = "Username '$username' is already taken. Try '$suggested_username' instead.";
                    }
                } else {
                    $errors[] = "Email '$email' is already registered.";
                }
            } else {
                // Proceed with registration
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $insert_sql = "INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, 'user')";
                $stmt_insert = $conn->prepare($insert_sql);
                if (!$stmt_insert) {
                    throw new mysqli_sql_exception("Prepare failed: " . $conn->error);
                }
                $stmt_insert->bind_param("sss", $username, $email, $hashed_password);
                if ($stmt_insert->execute()) {
                    $success_message = "Registration successful! Please log in.";
                    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                    header("Location: login.php");
                    exit();
                } else {
                    throw new mysqli_sql_exception("Execute failed: " . $conn->error);
                }
            }
        }
    } elseif ($_SERVER["REQUEST_METHOD"] == "POST") {
        $errors[] = "Invalid CSRF token.";
    }
} catch (mysqli_sql_exception $e) {
    error_log(date('[Y-m-d H:i:s] ') . "Database Error in register.php: " . $e->getMessage() . " in " . $e->getFile() . " on line " . $e->getLine());
    $errors[] = "Registration failed due to a database error.";
} catch (Exception $e) {
    error_log(date('[Y-m-d H:i:s] ') . "Unexpected Error in register.php: " . $e->getMessage() . " in " . $e->getFile() . " on line " . $e->getLine());
    $errors[] = "An unexpected error occurred.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - TechFix Pro</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
    <style>
        .gradient-bg {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .service-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <div class="flex-shrink-0 flex items-center">
                        <i data-feather="settings" class="text-indigo-600 h-8 w-8"></i>
                        <span class="ml-2 text-xl font-bold text-gray-900">TechFix Pro</span>
                    </div>
                </div>
                <div class="hidden md:ml-6 md:flex md:items-center md:space-x-8">
                    <a href="index.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="home" class="mr-1"></i> Home
                    </a>
                    <a href="login.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="log-in" class="mr-1"></i> Login
                    </a>
                    <a href="register.php" class="text-gray-900 bg-indigo-50 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="user-plus" class="mr-1"></i> Register
                    </a>
                </div>
                <div class="-mr-2 flex items-center md:hidden">
                    <button type="button" class="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-indigo-500" aria-controls="mobile-menu" aria-expanded="false" id="mobile-menu-button">
                        <span class="sr-only">Open main menu</span>
                        <i data-feather="menu"></i>
                    </button>
                </div>
            </div>
        </div>

        <!-- Mobile menu -->
        <div class="hidden md:hidden" id="mobile-menu">
            <div class="pt-2 pb-3 space-y-1">
                <a href="index.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="home" class="mr-2"></i> Home
                </a>
                <a href="login.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="log-in" class="mr-2"></i> Login
                </a>
                <a href="register.php" class="bg-indigo-50 border-indigo-500 text-indigo-700 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="user-plus" class="mr-2"></i> Register
                </a>
            </div>
        </div>
    </nav>

    <!-- Registration Form -->
    <div class="py-12 bg-gray-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="max-w-md mx-auto">
                <div class="bg-white shadow-lg rounded-lg p-6" data-aos="fade-up">
                    <h2 class="text-2xl font-bold text-gray-900 mb-6">Register</h2>
                    <?php if ($success_message) { ?>
                        <div class="mb-4 bg-green-100 border-l-4 border-green-500 text-green-700 p-4" data-aos="fade-up" data-aos-delay="100">
                            <?php echo htmlspecialchars($success_message); ?>
                        </div>
                    <?php } ?>
                    <?php if (!empty($errors)) { ?>
                        <div class="mb-4 bg-red-100 border-l-4 border-red-500 text-red-700 p-4" data-aos="fade-up" data-aos-delay="100">
                            <?php foreach ($errors as $error) { echo htmlspecialchars($error) . "<br>"; } ?>
                        </div>
                    <?php } ?>
                    <form method="POST" class="space-y-6">
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                        <div data-aos="fade-up" data-aos-delay="200">
                            <label for="username" class="block text-sm font-medium text-gray-700">Username</label>
                            <div class="mt-1 relative">
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <i data-feather="user" class="h-5 w-5 text-gray-400"></i>
                                </div>
                                <input type="text" name="username" id="username" class="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" value="<?php echo htmlspecialchars($_POST['username'] ?? ($suggested_username ?: '')); ?>" required>
                            </div>
                        </div>
                        <div data-aos="fade-up" data-aos-delay="300">
                            <label for="email" class="block text-sm font-medium text-gray-700">Email</label>
                            <div class="mt-1 relative">
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <i data-feather="mail" class="h-5 w-5 text-gray-400"></i>
                                </div>
                                <input type="email" name="email" id="email" class="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" required>
                            </div>
                        </div>
                        <div data-aos="fade-up" data-aos-delay="400">
                            <label for="password" class="block text-sm font-medium text-gray-700">Password</label>
                            <div class="mt-1 relative">
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <i data-feather="lock" class="h-5 w-5 text-gray-400"></i>
                                </div>
                                <input type="password" name="password" id="password" class="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" required>
                            </div>
                        </div>
                        <div data-aos="fade-up" data-aos-delay="500">
                            <label for="confirm_password" class="block text-sm font-medium text-gray-700">Confirm Password</label>
                            <div class="mt-1 relative">
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <i data-feather="lock" class="h-5 w-5 text-gray-400"></i>
                                </div>
                                <input type="password" name="confirm_password" id="confirm_password" class="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" required>
                            </div>
                        </div>
                        <div data-aos="fade-up" data-aos-delay="600">
                            <button type="submit" class="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                                <i data-feather="user-plus" class="mr-2"></i> Register
                            </button>
                        </div>
                    </form>
                    <div class="mt-4 text-center" data-aos="fade-up" data-aos-delay="700">
                        <p class="text-sm text-gray-600">Already have an account? <a href="login.php" class="font-medium text-indigo-600 hover:text-indigo-500">Log in</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-gray-800">
        <div class="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-2 gap-8 md:grid-cols-4">
                <div>
                    <h3 class="text-white text-sm font-semibold tracking-wider uppercase">Services</h3>
                    <ul class="mt-4 space-y-4">
                        <li><a href="#" class="text-gray-300 hover:text-white">Hardware Repair</a></li>
                        <li><a href="#" class="text-gray-300 hover:text-white">Virus Removal</a></li>
                        <li><a href="#" class="text-gray-300 hover:text-white">Data Recovery</a></li>
                        <li><a href="#" class="text-gray-300 hover:text-white">Software Installation</a></li>
                    </ul>
                </div>
                <div>
                    <h3 class="text-white text-sm font-semibold tracking-wider uppercase">Support</h3>
                    <ul class="mt-4 space-y-4">
                        <li><a href="contact.php" class="text-gray-300 hover:text-white">Contact Us</a></li>
                    </ul>
                </div>
                <div>
                    <h3 class="text-white text-sm font-semibold tracking-wider uppercase">Company</h3>
                    <ul class="mt-4 space-y-4">
                        <li><a href="about.php" class="text-gray-300 hover:text-white">About Us</a></li>
                    </ul>
                </div>
                <div>
                    <h3 class="text-white text-sm font-semibold tracking-wider uppercase">Connect</h3>
                    <div class="mt-4 flex space-x-6">
                        <a href="#" class="text-gray-400 hover:text-white">
                            <i data-feather="facebook"></i>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-white">
                            <i data-feather="twitter"></i>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-white">
                            <i data-feather="instagram"></i>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-white">
                            <i data-feather="linkedin"></i>
                        </a>
                    </div>
                    <div class="mt-6">
                        <p class="text-gray-300">Email us at: <a href="mailto:support@techfixpro.com" class="text-indigo-400 hover:text-indigo-300">support@techfixpro.com</a></p>
                    </div>
                </div>
            </div>
            <div class="mt-12 border-t border-gray-700 pt-8">
                <p class="text-base text-gray-400 text-center">
                    &copy; 2025 TechFix Pro. All rights reserved.
                </p>
            </div>
        </div>
    </footer>

    <script>
        AOS.init();
        feather.replace();
        document.getElementById('mobile-menu-button').addEventListener('click', function() {
            const menu = document.getElementById('mobile-menu');
            menu.classList.toggle('hidden');
        });
    </script>
</body>
</html>

<?php
try {
    $conn->close();
} catch (Exception $e) {
    error_log(date('[Y-m-d H:i:s] ') . "Database Close Error in register.php: " . $e->getMessage() . " in " . $e->getFile() . " on line " . $e->getLine());
}
?>