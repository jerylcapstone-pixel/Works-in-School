<?php
session_start();
require_once 'config.php';

// Initialize CSRF token
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

try {
    // Check database connection
    if (!$conn || $conn->connect_error) {
        error_log(date('[Y-m-d H:i:s] ') . "Database connection failed: " . ($conn ? $conn->connect_error : "No connection object"));
        throw new Exception("Unable to connect to the database.");
    }

    // Validate session and user existence
    if (!isset($_SESSION['user_id'])) {
        error_log(date('[Y-m-d H:i:s] ') . "Unauthorized access attempt to book.php: No user session");
        header("Location: login.php");
        exit();
    }

    $user_id = $_SESSION['user_id'];
    $sql = "SELECT id, role FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new mysqli_sql_exception("Prepare failed: " . $conn->error);
    }
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows === 0) {
        session_destroy();
        header("Location: login.php");
        exit();
    }
    $user_data = $result->fetch_assoc();
    $is_admin = $user_data['role'] === 'admin';
    $stmt->close();

    $errors = [];
    $success_message = "";

    // Check for session error message (e.g., from profile redirect)
    if (isset($_SESSION['error_message'])) {
        $errors[] = $_SESSION['error_message'];
        unset($_SESSION['error_message']);
    }

    // Check if profile is complete
    $sql = "SELECT username, email, phone, address FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new mysqli_sql_exception("Prepare failed: " . $conn->error);
    }
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$user) {
        throw new Exception("User not found.");
    }
    if (empty($user['username']) || empty($user['email']) || empty($user['phone']) || empty($user['address'])) {
        $_SESSION['error_message'] = "Please complete your profile before booking a service.";
        header("Location: profile.php");
        exit();
    }

    // Generate time options for booking hours (08:00 to 17:00)
    $time_options = [];
    for ($hour = 8; $hour < 18; $hour++) {
        $time_options[] = str_pad($hour, 2, '0', STR_PAD_LEFT) . ':00';
    }

    // Handle booking submission
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['csrf_token']) && $_POST['csrf_token'] === $_SESSION['csrf_token']) {
        $service_type = trim($_POST['service_type'] ?? '');
        $booking_date = trim($_POST['booking_date'] ?? '');
        $booking_time = trim($_POST['booking_time'] ?? '');
        $description = trim($_POST['description'] ?? '');

        // Validate inputs
        $allowed_services = ['Hardware Repair', 'Virus Removal', 'Data Recovery', 'Software Installation'];
        if (!in_array($service_type, $allowed_services)) {
            $errors[] = "Invalid service type.";
        }
        if (!preg_match("/^\d{4}-\d{2}-\d{2}$/", $booking_date) || strtotime($booking_date) < strtotime(date('Y-m-d'))) {
            $errors[] = "Invalid or past booking date.";
        }
        if (!preg_match("/^([0-1][0-9]|1[0-7]):00$/", $booking_time)) {
            $errors[] = "Booking time must be between 08:00 and 17:00 on the hour.";
        }
        if (strlen($description) > 1000) {
            $errors[] = "Description is too long (max 1000 characters).";
        }

        if (empty($errors)) {
            // Check if the selected time slot is available
            $overlap_sql = "SELECT COUNT(*) as count FROM bookings WHERE booking_date = ? AND booking_time = ? AND status NOT IN ('Cancelled', 'Completed')";
            $stmt_overlap = $conn->prepare($overlap_sql);
            if (!$stmt_overlap) {
                throw new mysqli_sql_exception("Prepare failed for overlap check: " . $conn->error);
            }
            $stmt_overlap->bind_param("ss", $booking_date, $booking_time);
            $stmt_overlap->execute();
            $overlap_result = $stmt_overlap->get_result()->fetch_assoc();
            if ($overlap_result['count'] > 0) {
                $errors[] = "The selected time slot is already booked.";
            }
            $stmt_overlap->close();

            if (empty($errors)) {
                $insert_sql = "INSERT INTO bookings (user_id, service_type, booking_date, booking_time, description, status) VALUES (?, ?, ?, ?, ?, 'Pending')";
                $stmt_insert = $conn->prepare($insert_sql);
                if (!$stmt_insert) {
                    throw new mysqli_sql_exception("Prepare failed: " . $conn->error);
                }
                $stmt_insert->bind_param("issss", $user_id, $service_type, $booking_date, $booking_time, $description);
                if ($stmt_insert->execute()) {
                    $success_message = "Booking submitted successfully!";
                    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                    header("Location: bookings.php");
                    exit();
                } else {
                    throw new mysqli_sql_exception("Execute failed: " . $stmt_insert->error);
                }
                $stmt_insert->close();
            }
        }
    } elseif ($_SERVER["REQUEST_METHOD"] == "POST") {
        $errors[] = "Invalid CSRF token.";
    }
} catch (mysqli_sql_exception $e) {
    error_log(date('[Y-m-d H:i:s] ') . "Database Error in book.php: " . $e->getMessage() . " (Code: " . $e->getCode() . ") in " . $e->getFile() . " on line " . $e->getLine());
    $errors[] = $is_admin ? "Database error: " . htmlspecialchars($e->getMessage()) : "Booking failed due to a database error.";
} catch (Exception $e) {
    error_log(date('[Y-m-d H:i:s] ') . "Unexpected Error in book.php: " . $e->getMessage() . " in " . $e->getFile() . " on line " . $e->getLine());
    $errors[] = "An unexpected error occurred.";
}

// Get booked times for the selected date if available
$booked_times = [];
if (isset($_GET['date']) || (isset($_POST['booking_date']) && !empty($_POST['booking_date']))) {
    $date_to_check = isset($_GET['date']) ? $_GET['date'] : $_POST['booking_date'];
    
    if (preg_match("/^\d{4}-\d{2}-\d{2}$/", $date_to_check)) {
        $sql = "SELECT booking_time FROM bookings WHERE booking_date = ? AND status NOT IN ('Cancelled', 'Completed')";
        $stmt = $conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param("s", $date_to_check);
            $stmt->execute();
            $result = $stmt->get_result();
            while ($row = $result->fetch_assoc()) {
                $booked_times[] = $row['booking_time'];
            }
            $stmt->close();
        }
    }
}

// Handle AJAX request for availability check
if (isset($_GET['ajax']) && $_GET['ajax'] == 'check_availability' && isset($_GET['date'])) {
    header('Content-Type: application/json');
    echo json_encode(['booked_times' => $booked_times]);
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Service - TechFix Pro</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
    <style>
        .gradient-bg {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .service-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        }
        html, body {
            height: 100%;
        }
        body {
            display: flex;
            flex-direction: column;
        }
        main {
            flex: 1 0 auto;
        }
        footer {
            flex-shrink: 0;
        }
        .time-slot {
            display: inline-block;
            padding: 0.5rem 1rem;
            margin: 0.25rem;
            border-radius: 0.25rem;
            cursor: pointer;
            transition: all 0.2s;
            border: 1px solid #d1d5db;
        }
        .time-slot:hover {
            background-color: #e5e7eb;
        }
        .time-slot.selected {
            background-color: #3b82f6;
            color: white;
            border-color: #3b82f6;
        }
        .time-slot.unavailable {
            background-color: #ef4444;
            color: white;
            cursor: not-allowed;
            border-color: #ef4444;
        }
        .time-slot.past {
            background-color: #9ca3af;
            color: white;
            cursor: not-allowed;
            border-color: #9ca3af;
        }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <div class="flex-shrink-0 flex items-center">
                        <i data-feather="settings" class="text-indigo-600 h-8 w-8"></i>
                        <span class="ml-2 text-xl font-bold text-gray-900">TechFix Pro</span>
                    </div>
                </div>
                <div class="hidden md:ml-6 md:flex md:items-center md:space-x-8">
                    <a href="index.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="home" class="mr-1"></i> Home
                    </a>
                    <a href="services.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="tool" class="mr-1"></i> Services
                    </a>
                    <a href="book.php" class="text-gray-900 bg-indigo-50 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="calendar" class="mr-1"></i> Book Service
                    </a>
                    <a href="bookings.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="list" class="mr-1"></i> My Bookings
                    </a>
                    <a href="profile.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="user" class="mr-1"></i> Profile
                    </a>
                    <?php if ($is_admin) { ?>
                    <a href="admin_bookings.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="shield" class="mr-1"></i> Admin Panel
                    </a>
                    <?php } ?>
                    <a href="logout.php" class="text-gray-900 hover:text-indigo-600 px-3 py-2 text-sm font-medium flex items-center">
                        <i data-feather="log-out" class="mr-1"></i> Logout
                    </a>
                </div>
                <div class="-mr-2 flex items-center md:hidden">
                    <button type="button" class="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-indigo-500" aria-controls="mobile-menu" aria-expanded="false" id="mobile-menu-button">
                        <span class="sr-only">Open main menu</span>
                        <i data-feather="menu"></i>
                    </button>
                </div>
            </div>
        </div>
        <div class="hidden md:hidden" id="mobile-menu">
            <div class="pt-2 pb-3 space-y-1">
                <a href="index.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="home" class="mr-2"></i> Home
                </a>
                <a href="services.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="tool" class="mr-2"></i> Services
                </a>
                <a href="book.php" class="bg-indigo-50 border-indigo-500 text-indigo-700 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="calendar" class="mr-2"></i> Book Service
                </a>
                <a href="bookings.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="list" class="mr-2"></i> My Bookings
                </a>
                <a href="profile.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="user" class="mr-2"></i> Profile
                </a>
                <?php if ($is_admin) { ?>
                <a href="admin_bookings.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="shield" class="mr-2"></i> Admin Panel
                </a>
                <?php } ?>
                <a href="logout.php" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium flex items-center">
                    <i data-feather="log-out" class="mr-2"></i> Logout
                </a>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main>
        <div class="py-12 bg-gray-50">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="max-w-md mx-auto">
                    <div class="bg-white shadow-lg rounded-lg p-6" data-aos="fade-up">
                        <h2 class="text-2xl font-bold text-gray-900 mb-6">Book a Service</h2>
                        <?php if ($success_message) { ?>
                            <div class="mb-4 bg-green-100 border-l-4 border-green-500 text-green-700 p-4" data-aos="fade-up" data-aos-delay="100">
                                <?php echo htmlspecialchars($success_message); ?>
                            </div>
                        <?php } ?>
                        <?php if (!empty($errors)) { ?>
                            <div class="mb-4 bg-red-100 border-l-4 border-red-500 text-red-700 p-4" data-aos="fade-up" data-aos-delay="100">
                                <?php foreach ($errors as $error) { echo htmlspecialchars($error) . "<br>"; } ?>
                            </div>
                        <?php } ?>
                        <form method="POST" class="space-y-6" id="bookingForm">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                            <div data-aos="fade-up" data-aos-delay="200">
                                <label for="service_type" class="block text-sm font-medium text-gray-700">Service Type</label>
                                <div class="mt-1 relative">
                                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                        <i data-feather="tool" class="h-5 w-5 text-gray-400"></i>
                                    </div>
                                    <select name="service_type" id="service_type" class="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" required>
                                        <option value="" disabled selected>Select a service</option>
                                        <option value="Hardware Repair" <?php echo (isset($_POST['service_type']) && $_POST['service_type'] == 'Hardware Repair') ? 'selected' : ''; ?>>Hardware Repair</option>
                                        <option value="Virus Removal" <?php echo (isset($_POST['service_type']) && $_POST['service_type'] == 'Virus Removal') ? 'selected' : ''; ?>>Virus Removal</option>
                                        <option value="Data Recovery" <?php echo (isset($_POST['service_type']) && $_POST['service_type'] == 'Data Recovery') ? 'selected' : ''; ?>>Data Recovery</option>
                                        <option value="Software Installation" <?php echo (isset($_POST['service_type']) && $_POST['service_type'] == 'Software Installation') ? 'selected' : ''; ?>>Software Installation</option>
                                    </select>
                                </div>
                            </div>
                            <div data-aos="fade-up" data-aos-delay="300">
                                <label for="booking_date" class="block text-sm font-medium text-gray-700">Booking Date</label>
                                <div class="mt-1 relative">
                                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                        <i data-feather="calendar" class="h-5 w-5 text-gray-400"></i>
                                    </div>
                                    <input type="date" name="booking_date" id="booking_date" min="<?php echo date('Y-m-d'); ?>" value="<?php echo isset($_POST['booking_date']) ? htmlspecialchars($_POST['booking_date']) : ''; ?>" class="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" required>
                                </div>
                            </div>
                            <div data-aos="fade-up" data-aos-delay="400">
                                <label class="block text-sm font-medium text-gray-700 mb-2">Booking Time</label>
                                <div id="time-slots-container" class="grid grid-cols-3 gap-2">
                                    <?php foreach ($time_options as $time): 
                                        $isBooked = in_array($time, $booked_times);
                                        $isPast = false;
                                        if (isset($_POST['booking_date']) && $_POST['booking_date'] == date('Y-m-d')) {
                                            $currentTime = date('H:i');
                                            $isPast = $time <= $currentTime;
                                        }
                                        $class = $isBooked ? 'unavailable' : ($isPast ? 'past' : '');
                                    ?>
                                        <div class="time-slot text-center <?php echo $class; ?>" data-time="<?php echo htmlspecialchars($time); ?>" title="<?php echo $isBooked ? 'Already booked' : ($isPast ? 'Time has passed' : 'Available'); ?>">
                                            <?php echo htmlspecialchars($time); ?>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                                <input type="hidden" name="booking_time" id="selected_time" value="<?php echo isset($_POST['booking_time']) ? htmlspecialchars($_POST['booking_time']) : ''; ?>" required>
                                <p class="mt-2 text-sm text-gray-500">Available times are between 08:00 AM and 05:00 PM</p>
                            </div>
                            <div data-aos="fade-up" data-aos-delay="500">
                                <label for="description" class="block text-sm font-medium text-gray-700">Description</label>
                                <div class="mt-1">
                                    <textarea name="description" id="description" class="block w-full py-2 px-3 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" rows="4" placeholder="Describe the issue or requirements"><?php echo isset($_POST['description']) ? htmlspecialchars($_POST['description']) : ''; ?></textarea>
                                </div>
                            </div>
                            <div data-aos="fade-up" data-aos-delay="600">
                                <button type="submit" class="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                                    <i data-feather="calendar" class="mr-2"></i> Submit Booking
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="bg-gray-800">
        <div class="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-2 gap-8 md:grid-cols-4">
                <div>
                    <h3 class="text-white text-sm font-semibold tracking-wider uppercase">Services</h3>
                    <ul class="mt-4 space-y-4">
                        <li><a href="services.php#hardware-repair" class="text-gray-300 hover:text-white">Hardware Repair</a></li>
                        <li><a href="services.php#virus-removal" class="text-gray-300 hover:text-white">Virus Removal</a></li>
                        <li><a href="services.php#data-recovery" class="text-gray-300 hover:text-white">Data Recovery</a></li>
                        <li><a href="services.php#software-installation" class="text-gray-300 hover:text-white">Software Installation</a></li>
                    </ul>
                </div>
                <div>
                    <h3 class="text-white text-sm font-semibold tracking-wider uppercase">Support</h3>
                    <ul class="mt-4 space-y-4">
                        <li><a href="contact.php" class="text-gray-300 hover:text-white">Contact Us</a></li>
                    </ul>
                </div>
                <div>
                    <h3 class="text-white text-sm font-semibold tracking-wider uppercase">Company</h3>
                    <ul class="mt-4 space-y-4">
                        <li><a href="about.php" class="text-gray-300 hover:text-white">About Us</a></li>
                    </ul>
                </div>
                <div>
                    <h3 class="text-white text-sm font-semibold tracking-wider uppercase">Connect</h3>
                    <div class="mt-4 flex space-x-6">
                        <a href="#" class="text-gray-400 hover:text-white">
                            <i data-feather="facebook"></i>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-white">
                            <i data-feather="twitter"></i>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-white">
                            <i data-feather="instagram"></i>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-white">
                            <i data-feather="linkedin"></i>
                        </a>
                    </div>
                    <div class="mt-6">
                        <p class="text-gray-300">Email us at: <a href="mailto:support@techfixpro.com" class="text-indigo-400 hover:text-indigo-300">support@techfixpro.com</a></p>
                    </div>
                </div>
            </div>
            <div class="mt-12 border-t border-gray-700 pt-8">
                <p class="text-base text-gray-400 text-center">
                    &copy; 2025 TechFix Pro. All rights reserved.
                </p>
            </div>
        </div>
    </footer>

    <script>
        AOS.init();
        feather.replace();
        document.getElementById('mobile-menu-button').addEventListener('click', function() {
            const menu = document.getElementById('mobile-menu');
            menu.classList.toggle('hidden');
        });

        // Time slot selection
        document.querySelectorAll('.time-slot').forEach(slot => {
            slot.addEventListener('click', function() {
                if (!this.classList.contains('unavailable') && !this.classList.contains('past')) {
                    document.querySelectorAll('.time-slot').forEach(s => s.classList.remove('selected'));
                    this.classList.add('selected');
                    document.getElementById('selected_time').value = this.getAttribute('data-time');
                }
            });
        });

        // Update time slots based on selected date
        function updateTimeSlots() {
            const dateInput = document.getElementById('booking_date');
            const selectedDate = dateInput.value;
            const today = new Date().toISOString().split('T')[0];
            const now = new Date();
            const currentHour = now.getHours();
            const currentMinute = now.getMinutes();

            // Reset all time slots
            document.querySelectorAll('.time-slot').forEach(slot => {
                slot.classList.remove('selected', 'unavailable', 'past');
                slot.style.cursor = 'pointer';
                slot.title = 'Available';
            });
            document.getElementById('selected_time').value = '';

            // Check booked time slots via AJAX
            if (selectedDate) {
                fetch('book.php?ajax=check_availability&date=' + encodeURIComponent(selectedDate))
                .then(response => response.json())
                .then(data => {
                    if (data.booked_times) {
                        document.querySelectorAll('.time-slot').forEach(slot => {
                            const time = slot.getAttribute('data-time');
                            if (data.booked_times.includes(time)) {
                                slot.classList.add('unavailable');
                                slot.style.cursor = 'not-allowed';
                                slot.title = 'This time slot is already booked';
                            }
                        });
                    }
                    
                    // If selected date is today, disable past times
                    if (selectedDate === today) {
                        document.querySelectorAll('.time-slot').forEach(slot => {
                            const time = slot.getAttribute('data-time');
                            const [hour, minute] = time.split(':').map(Number);
                            if (hour < currentHour || (hour === currentHour && minute < currentMinute)) {
                                slot.classList.add('past');
                                slot.style.cursor = 'not-allowed';
                                slot.title = 'This time slot has passed';
                            }
                        });
                    }
                })
                .catch(error => console.error('Error checking availability:', error));
            }
        }

        // Initialize time slots and add event listener for date changes
        document.getElementById('booking_date').addEventListener('change', updateTimeSlots);
        
        // Preselect time if form was submitted with errors
        <?php if (isset($_POST['booking_time']) && !empty($_POST['booking_time'])): ?>
            document.addEventListener('DOMContentLoaded', function() {
                const timeSlot = document.querySelector(`.time-slot[data-time="<?php echo $_POST['booking_time']; ?>"]`);
                if (timeSlot && !timeSlot.classList.contains('unavailable') && !timeSlot.classList.contains('past')) {
                    timeSlot.classList.add('selected');
                }
                updateTimeSlots();
            });
        <?php else: ?>
            document.addEventListener('DOMContentLoaded', updateTimeSlots);
        <?php endif; ?>

        // Form validation
        document.getElementById('bookingForm').addEventListener('submit', function(e) {
            const date = document.getElementById('booking_date').value;
            const time = document.getElementById('selected_time').value;

            if (!date || !time) {
                e.preventDefault();
                alert('Please select both a date and a time for booking.');
                return false;
            }

            if (!time.match(/^([0-1][0-9]|1[0-7]):00$/)) {
                e.preventDefault();
                alert('Booking time must be between 08:00 and 17:00 on the hour.');
                return false;
            }

            const selectedDatetime = new Date(date + 'T' + time + ':00');
            const now = new Date();
            if (selectedDatetime <= now) {
                e.preventDefault();
                alert('Please select a future date and time for booking.');
                return false;
            }

            // Check booking end time (1 hour duration) does not extend past 18:00
            const closingTime = new Date(date + 'T18:00:00');
            const bookingEndTime = new Date(selectedDatetime);
            bookingEndTime.setHours(bookingEndTime.getHours() + 1);
            if (bookingEndTime > closingTime) {
                e.preventDefault();
                alert('Booking cannot extend beyond 6:00 PM closing time. Please choose an earlier time.');
                return false;
            }

            return true;
        });
    </script>
</body>
</html>

<?php
// Close database connection after all operations
if (isset($conn) && $conn instanceof mysqli) {
    $conn->close();
}
?>